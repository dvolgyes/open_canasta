import { readFileSync, writeFileSync } from "node:fs";
import { modernStudyPlan, parseModernStudyConfig } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/research/modern-study.ts";

const previous = [
	...readFileSync("/tmp/open-canasta-existing-pair-files.txt", "utf8").trim().split("\n"),
	...readFileSync("/tmp/open-canasta-grid-pair-files.txt", "utf8").trim().split("\n"),
].filter(Boolean);
const existing = new Set<number>();
for (const path of previous) {
	const record = JSON.parse(readFileSync(path, "utf8"));
	if (typeof record.plan?.seed === "number") existing.add(record.plan.seed);
}
const old = JSON.parse(readFileSync("docs/modern-knownpair-vs-handcrafted-100-results/manifest.json", "utf8")).identity.config;
delete old.aKnownPairV1Weight;
const planned = new Set<number>();
for (const [opponent, split] of [["handcrafted", 0], ["zero", 1]] as const) {
	const input = { ...old, seed: 3917, split, aPairThreatV1Weight: 50, b: opponent === "zero" ? null : old.b };
	const parsed = parseModernStudyConfig(input);
	if (!parsed.ok) throw new Error(parsed.reason);
	for (let index = 0; index < 50; index++) {
		const seed = modernStudyPlan(parsed.config, index, 0).seed;
		if (existing.has(seed) || planned.has(seed)) throw new Error(`duplicate deal seed ${seed}`);
		planned.add(seed);
	}
	writeFileSync(`docs/modern-pair-heldout-${opponent}.json`, `${JSON.stringify(input, null, "\t")}\n`);
}
if (planned.size !== 100 || existing.size === 0) throw new Error("seed check incomplete");
console.log(JSON.stringify({ existingSeeds: existing.size, distinctNewSeeds: planned.size }));
