import { search } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/mcts.ts";
import { mulberry32 } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/random.ts";

type State = { bit: number; stage: number; guess?: number };
type Action = "pass" | "guess0" | "guess1";
const rng = mulberry32(314159);
const result = await search<State, Action>({
	sample: () => ({ bit: Math.floor(rng() * 2), stage: 0 }),
	player: (state) => state.stage,
	key: (_state, action) => action,
	actions: (state) => state.stage === 0 ? ["pass"] : ["guess0", "guess1"],
	apply: (state, action) => action === "pass"
		? { ...state, stage: 1 }
		: { ...state, stage: 2, guess: action === "guess0" ? 0 : 1 },
	terminal: (state) => state.stage === 2,
	evaluate: (state) => state.guess === state.bit ? [0, 1] : [1, 0],
}, { timeMs: 30000, maxIterations: 10000, maxDepth: 2, rng });
if (result.iterations !== 10000 || result.choices.length !== 1) throw new Error("incomplete search");
const { elapsedMs: _elapsedMs, ...stableResult } = result;
console.log(JSON.stringify(stableResult));
