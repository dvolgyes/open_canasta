import { readFileSync, readdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { modernStudyPlan, parseModernStudyConfig } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/research/modern-study.ts";

const existing = new Set<number>();
for (const path of readFileSync("/tmp/open-canasta-all-pair-files.txt", "utf8").trim().split("\n").filter(Boolean)) {
	const record = JSON.parse(readFileSync(path, "utf8"));
	if (typeof record.plan?.seed === "number") existing.add(record.plan.seed);
}
for (const name of ["handcrafted", "zero"]) {
	const parsed = parseModernStudyConfig(JSON.parse(readFileSync(`docs/modern-pair-confirm-${name}.json`, "utf8")));
	if (!parsed.ok) throw new Error(parsed.reason);
	for (let i = 0; i < parsed.config.pairs; i++) existing.add(modernStudyPlan(parsed.config, i, 0).seed);
}
for (const name of readdirSync("docs/modern-pair-pile-grid-configs")) {
	const parsed = parseModernStudyConfig(JSON.parse(readFileSync(join("docs/modern-pair-pile-grid-configs", name), "utf8")));
	if (!parsed.ok) throw new Error(parsed.reason);
	for (let i = 0; i < parsed.config.pairs; i++) existing.add(modernStudyPlan(parsed.config, i, 0).seed);
}
for (let seed = 27000; seed <= 27011; seed++) existing.add(seed);
for (let seed = 28000; seed <= 28023; seed++) existing.add(seed);
const old = JSON.parse(readFileSync("docs/modern-pair-heldout-handcrafted.json", "utf8"));
const input = { ...old, seed: 6913, split: 0, aPairPileV1Weight: 50, bPairThreatV1Weight: 50 };
const parsed = parseModernStudyConfig(input);
if (!parsed.ok) throw new Error(parsed.reason);
const planned = new Set<number>();
for (let i = 0; i < parsed.config.pairs; i++) {
	const seed = modernStudyPlan(parsed.config, i, 0).seed;
	if (existing.has(seed) || planned.has(seed)) throw new Error(`duplicate deal seed ${seed}`);
	planned.add(seed);
}
if (planned.size !== 50 || existing.size < 800) throw new Error("seed check incomplete");
writeFileSync("docs/modern-pair-pile-heldout-config.json", `${JSON.stringify(input, null, "\t")}\n`);
console.log(JSON.stringify({ existingSeeds: existing.size, distinctNewSeeds: planned.size }));
