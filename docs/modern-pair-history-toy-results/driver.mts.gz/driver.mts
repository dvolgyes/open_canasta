import { inferCards, sampleCards } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/card-knowledge.ts";
import { relaxedPairChance } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/relaxed-card-pair.ts";
import { exactCardHistory, uniformDiscardLikelihood } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/research/exact-card-history.ts";
import { mulberry32 } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/random.ts";

const exact = exactCardHistory({
	unknown: ["A1", "A2", "B", "C"], publicCards: ["A1"], rowCounts: [2, 2],
	events: [{ kind: "gain", player: 0, faces: ["A1"] }, { kind: "discard", player: 0, face: "A1" }],
	discardLikelihood: uniformDiscardLikelihood, maxStates: 1000,
});
if (!exact.ok) throw new Error(exact.reason);
const rank = new Set(["A1", "A2"]);
const exactPair = exact.worlds.reduce((sum, world) => sum + (world.rows[0].filter((face) => rank.has(face)).length >= 2 ? world.probability : 0), 0);
const belief = inferCards({
	deck: ["A1", "A1", "A2", "B", "C", "E"], observer: 0, own: ["E"], publicCards: ["A1"], counts: [1, 2, 2],
	history: { initialCounts: [1, 2, 2], events: [
		{ player: 1, gained: ["A1"], removed: [], drawn: 0 },
		{ player: 1, gained: [], removed: ["A1"], drawn: 0 },
	] },
});
const relaxed = relaxedPairChance(belief, [1], ["A1", "A2"]);
const rng = mulberry32(271828);
let sampledPairs = 0;
for (let i = 0; i < 20000; i++) {
	const rows = sampleCards(belief, rng);
	if (rows[1].filter((face) => rank.has(face)).length >= 2) sampledPairs++;
}
console.log(JSON.stringify({ evidenceProbability: exact.evidenceProbability, exactPair, relaxedPair: relaxed, samples: 20000, sampledPairs, sampledFrequency: sampledPairs / 20000 }));
