import { sampleCards, type CardBelief } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/card-knowledge.ts";
import { mulberry32 } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/random.ts";

const belief: CardBelief = {
	faces: ["A", "B", "C"],
	remaining: { A: 2, B: 1, C: 1 },
	players: [
		{ count: 2, minimum: { A: 1, B: 0, C: 0 }, maximum: { A: 2, B: 1, C: 1 } },
		{ count: 2, minimum: { A: 0, B: 0, C: 0 }, maximum: { A: 2, B: 1, C: 1 } },
	],
};
const labelled = ["A1", "A2", "B", "C"];
let exactValid = 0, exactBothA = 0;
for (let i = 0; i < labelled.length; i++) for (let j = i + 1; j < labelled.length; j++) {
	const cards = [labelled[i], labelled[j]];
	if (!cards.some((card) => card?.startsWith("A"))) continue;
	exactValid++;
	if (cards.every((card) => card?.startsWith("A"))) exactBothA++;
}
const rng = mulberry32(314159);
const samples = 20000;
let observedBothA = 0;
for (let i = 0; i < samples; i++) {
	const allocation = sampleCards(belief, rng);
	const first = allocation[0];
	if (!first || first.length !== 2 || !first.includes("A")) throw new Error("invalid allocation");
	if (first.filter((face) => face === "A").length === 2) observedBothA++;
}
console.log(JSON.stringify({ labelledDeals: exactValid, labelledBothA: exactBothA, uniformPhysicalProbability: exactBothA / exactValid, samples, observedBothA, observedProbability: observedBothA / samples, fixedCopyPrediction: 1 / 3, fallbackPossible: false }));
