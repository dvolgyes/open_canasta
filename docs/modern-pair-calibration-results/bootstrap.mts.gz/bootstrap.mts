import { readFileSync } from "node:fs";
import { mulberry32 } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/random.ts";

const path = process.argv[2];
if (!path) throw new Error("missing calibration records");
const rows = readFileSync(path, "utf8").trim().split("\n").map(JSON.parse);
const hands = new Map<number, { score: number; dealer: number; count: number; gap: number }>();
for (const row of rows) {
	if (!Number.isSafeInteger(row.seed) || !Number.isFinite(row.estimate) || row.estimate < 0 || row.estimate > 1 || ![0, 1].includes(row.actual)) throw new Error("invalid calibration record");
	const hand = hands.get(row.seed) ?? { score: row.score, dealer: row.dealer, count: 0, gap: 0 };
	if (hand.score !== row.score || hand.dealer !== row.dealer) throw new Error("inconsistent hand stratum");
	hand.count++;
	hand.gap += row.estimate - row.actual;
	hands.set(row.seed, hand);
}
const strata = [];
for (const score of [0, 3000, 5000]) for (const dealer of [0, 1, 2, 3]) {
	const group = [...hands.values()].filter((hand) => hand.score === score && hand.dealer === dealer);
	if (group.length !== 2) {
		console.log(JSON.stringify({ eligible: false, reason: "missing hand positions", score, dealer, recordedHands: group.length }));
		process.exit(0);
	}
	strata.push(group);
}
if (hands.size !== 24) throw new Error("unexpected extra hands");
const rng = mulberry32(81427), replicates = [];
for (let i = 0; i < 10000; i++) {
	let count = 0, gap = 0;
	for (const group of strata) for (let j = 0; j < 2; j++) {
		const hand = group[Math.floor(rng() * group.length)];
		count += hand.count;
		gap += hand.gap;
	}
	replicates.push(gap / count);
}
replicates.sort((a, b) => a - b);
console.log(JSON.stringify({ eligible: true, hands: hands.size, replicates: replicates.length, lower: replicates[Math.floor((replicates.length - 1) * .025)], upper: replicates[Math.floor((replicates.length - 1) * .975)] }));
