import { readFileSync } from "node:fs";

const path = process.argv[2];
if (!path) throw new Error("missing calibration records");
const rows = readFileSync(path, "utf8").trim().split("\n").map(JSON.parse);
if (!rows.length) throw new Error("no calibration positions");
const bins = Array.from({ length: 10 }, (_, index) => ({ index, count: 0, estimateSum: 0, actualSum: 0 }));
let estimateSum = 0, actualSum = 0, brierSum = 0;
for (const row of rows) {
	if (!Number.isFinite(row.estimate) || row.estimate < 0 || row.estimate > 1 || ![0, 1].includes(row.actual)) throw new Error("invalid calibration record");
	estimateSum += row.estimate;
	actualSum += row.actual;
	brierSum += (row.estimate - row.actual) ** 2;
	const bin = bins[Math.min(9, Math.floor(row.estimate * 10))];
	bin.count++;
	bin.estimateSum += row.estimate;
	bin.actualSum += row.actual;
}
const count = rows.length;
console.log(JSON.stringify({
	positions: count,
	handsWithPositions: new Set(rows.map((row) => row.seed)).size,
	meanEstimate: estimateSum / count,
	observedFrequency: actualSum / count,
	absDifference: Math.abs(estimateSum - actualSum) / count,
	brier: brierSum / count,
	bins: bins.map((bin) => ({ index: bin.index, count: bin.count, meanEstimate: bin.count ? bin.estimateSum / bin.count : null, observedFrequency: bin.count ? bin.actualSum / bin.count : null })),
}));
