import { spawnSync } from "node:child_process";
import { writeFileSync } from "node:fs";

for (let trial = 1; trial <= 3; trial++) {
	const start = performance.now();
	const result = spawnSync(process.execPath, ["node_modules/vitest/vitest.mjs", "run", "tests/unit/research-cli.test.ts"], { encoding: "utf8", timeout: 60000 });
	writeFileSync(`/tmp/open-canasta-cli-timeout-trial-${trial}.log`, `${result.stdout}\n${result.stderr}`);
	console.log(JSON.stringify({ trial, elapsedMs: performance.now() - start, status: result.status, signal: result.signal }));
}
