import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

const root = mkdtempSync(join(tmpdir(), "canasta-study-timing-"));
const timings = [];
try {
	const config = { ...JSON.parse(readFileSync("docs/classic-capacity-pilot.json", "utf8")), maxActionsPerHand: 1, pairs: 2, parallelPairs: 2, maxWallMs: 10000 };
	const configPath = join(root, "config.json"), outputPath = join(root, "results");
	writeFileSync(configPath, JSON.stringify(config));
	const run = (label, resume = false) => {
		const start = performance.now();
		const result = spawnSync(process.execPath, ["--import", "tsx", "scripts/canasta-study.ts", configPath, outputPath, ...(resume ? ["--resume"] : [])], { encoding: "utf8", timeout: 20000 });
		timings.push({ label, elapsedMs: performance.now() - start, status: result.status, signal: result.signal });
		return result;
	};
	const first = run("initial");
	assert.equal(first.status, 1, first.stderr);
	assert.notEqual(first.stdout, "");
	assert.deepEqual(Object.fromEntries(Object.entries(JSON.parse(first.stdout)).filter(([key]) => ["planned", "completed", "lower", "upper"].includes(key))), { planned: 2, completed: 0, lower: 0, upper: 1 });
	const legs = [0, 1].map((i) => JSON.parse(readFileSync(join(outputPath, `evaluation-0-${i}.json`), "utf8")));
	assert.equal(legs[0].task.plan.seed, legs[1].task.plan.seed);
	assert.deepEqual(legs.map((leg) => leg.result.plan.aTeam), [0, 1]);
	assert.ok(legs.every((leg) => leg.result.reason === "action cap"));
	const resumed = run("resume", true);
	assert.equal(resumed.status, 1, resumed.stderr);
	assert.equal(resumed.stdout, first.stdout);
	assert.ok(!resumed.stderr.includes("match evaluation-"));
	writeFileSync(join(outputPath, "run.lock"), JSON.stringify({ pid: 0, host: "test" }));
	assert.ok(run("lock", true).stderr.includes("run.lock exists"));
	rmSync(join(outputPath, "run.lock"));
	writeFileSync(configPath, JSON.stringify({ ...config, seed: config.seed + 1 }));
	assert.ok(run("config", true).stderr.includes("identical configuration"));
	writeFileSync(configPath, JSON.stringify(config));
	writeFileSync(join(outputPath, "evaluation-0-0.json"), JSON.stringify({ ...legs[0], result: { ...legs[0].result, status: "complete", aWin: 1, scores: [0, 0] } }));
	assert.ok(run("corrupt", true).stderr.includes("invalid cached match"));
	console.log(JSON.stringify({ ok: true, timings, totalMs: timings.reduce((sum, item) => sum + item.elapsedMs, 0) }));
} finally {
	rmSync(root, { recursive: true, force: true });
}
