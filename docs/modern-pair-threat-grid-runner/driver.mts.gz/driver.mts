import { spawn, type ChildProcess } from "node:child_process";
import { existsSync, mkdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { summarizeModernHandPairs, validModernResult } from "/home/dvolgyes/workspace/worktrees/open-canasta-pair-grid/src/bot/research/modern-evidence.ts";
import { modernStudyPlan, parseModernStudyConfig } from "/home/dvolgyes/workspace/worktrees/open-canasta-pair-grid/src/bot/research/modern-study.ts";

const root = "/home/dvolgyes/workspace/worktrees/open-canasta-pair-grid";
const resultRoot = join(root, "docs/modern-pair-threat-grid-results");
const weights = [-100, -50, -25, 25, 50, 100];
const scores = [0, 3000, 5000];
mkdirSync(resultRoot, { recursive: true });
let child: ChildProcess | undefined;
let cancelled = false;
const stop = () => { cancelled = true; child?.kill("SIGINT"); };
process.on("SIGINT", stop);
process.on("SIGTERM", stop);
const data: { weight: number; wins: number; losses: number; ties: number }[] = [];
let completed = 0;
for (const weight of weights) {
	const totals = { weight, wins: 0, losses: 0, ties: 0 };
	for (const score of scores) {
		if (cancelled) process.exit(2);
		const label = `${weight < 0 ? `neg${-weight}` : `pos${weight}`}-${score}`;
		const configPath = join(root, `docs/modern-pair-threat-grid-configs/${label}.json`);
		const outputPath = join(resultRoot, label);
		const parsed = parseModernStudyConfig(JSON.parse(readFileSync(configPath, "utf8")));
		if (!parsed.ok) throw new Error(parsed.reason);
		const args = ["--import", "tsx", "scripts/modern-study.ts", configPath, outputPath];
		if (existsSync(outputPath)) args.push("--resume");
		const code = await new Promise<number | null>((resolve, reject) => {
			child = spawn(process.execPath, args, { cwd: root, stdio: ["ignore", "pipe", "pipe"] });
			let diagnostic = "";
			child.stdout?.on("data", () => {});
			child.stderr?.on("data", (chunk: Buffer) => { diagnostic = (diagnostic + chunk.toString()).slice(-20000); });
			child.once("error", reject);
			child.once("close", (result) => {
				child = undefined;
				if (!cancelled && result !== 2) process.stderr.write(diagnostic);
				resolve(result);
			});
		});
		if (cancelled) process.exit(2);
		if (code !== 2) throw new Error(`unexpected study exit for ${label}: ${code}`);
		const pairs = [];
		for (let pair = 0; pair < 8; pair++) {
			const legs = ([0, 1] as const).map((side) => {
				const path = join(outputPath, `pair-${pair}-team-${side}.json`);
				const result = JSON.parse(readFileSync(path, "utf8"));
				if (!validModernResult(result, modernStudyPlan(parsed.config, pair, side), 2)) throw new Error(`invalid ${label} leg`);
				return result;
			});
			pairs.push([legs[0], legs[1]] as const);
		}
		const summary = summarizeModernHandPairs(pairs, 8, 2);
		if (!summary.eligible) throw new Error(`ineligible training hands in ${label}`);
		totals.wins += summary.handWins;
		totals.losses += summary.handLosses;
		totals.ties += summary.tiedHands;
		process.stdout.write(`${JSON.stringify({ completedConfigs: ++completed, totalConfigs: 18 })}\n`);
	}
	data.push(totals);
}
const ordered = data.toSorted((a, b) =>
	(b.wins + b.ties / 2) - (a.wins + a.ties / 2) || Math.abs(a.weight) - Math.abs(b.weight) || a.weight - b.weight);
const winner = ordered[0];
if (!winner || data.some((entry) => entry.wins + entry.losses + entry.ties !== 48)) throw new Error("invalid completed grid");
const selectedWeight = winner.wins + winner.ties / 2 > 24 ? winner.weight : 0;
process.stdout.write(`${JSON.stringify({ status: "complete", data, selectedWeight })}\n`);
