import { modernStartMatch } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-match.ts";
import { modernApplyAction } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-hand.ts";
import { mulberry32 } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/random.ts";
import { recordModernTransfer, type ModernPublicHistory } from "/home/dvolgyes/workspace/open_canasta-bot/src/game/modern-history.ts";
import { observeModern } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-inference.ts";
import { chooseModernPosition } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-search.ts";
import { modernActionKey } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-actions.ts";

const started = modernStartMatch(9137, 0);
if (!started.ok) throw new Error(started.reason);
let hand = started.match.hand;
let history: ModernPublicHistory | undefined;
for (let decision = 0; decision < 20 && hand.outcome === null; decision++) {
	const view = observeModern(hand, hand.turn, history);
	const baseline = await chooseModernPosition(view, {
		timeMs: 30000,
		maxIterations: 2,
		maxDepth: 3,
		rng: mulberry32(1000 + decision),
	});
	const deeper = await chooseModernPosition(view, {
		timeMs: 30000,
		maxIterations: 8,
		maxDepth: 8,
		rng: mulberry32(1000 + decision),
	});
	if (!baseline.action || !deeper.action) throw new Error("missing action");
	const key = (action: typeof baseline.action) => modernActionKey(hand, action);
	console.log(JSON.stringify({
		decision,
		phase: hand.phase,
		baselineIterations: baseline.iterations,
		deeperIterations: deeper.iterations,
		baselineAction: key(baseline.action),
		deeperAction: key(deeper.action),
		deeperRootVisits: deeper.choices.map((choice) => choice.visits),
	}));
	const applied = modernApplyAction(hand, hand.turn, baseline.action);
	if (!applied.ok) throw new Error(applied.reason);
	history = recordModernTransfer(history, hand, applied.hand);
	hand = applied.hand;
}
