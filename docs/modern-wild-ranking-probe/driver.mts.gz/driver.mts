import { readFileSync } from "node:fs";
import { modernApplyAction } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-hand";
import { modernStartMatch } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-match";
import { modernActionKey, modernPlayableActions, modernSearchActions } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-actions";
import { MODERN_PRIOR_WEIGHTS, modernPriorFeatures, modernPriorValue } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-prior";

const rows = readFileSync("docs/modern-band-sensitivity-results/results.jsonl", "utf8")
	.trim().split("\n").map((line) => JSON.parse(line));
const groups = new Map<string, typeof rows>();
for (const row of rows) {
	const key = `${row.score}:${row.seed}`;
	const group = groups.get(key) ?? [];
	if (row.decision !== group.length) throw new Error(`invalid trajectory ${key}`);
	group.push(row);
	groups.set(key, group);
}
if (groups.size !== 15 || rows.length !== 1260) throw new Error("unexpected source");
for (const group of groups.values()) {
	const { seed, score } = group[0];
	const started = modernStartMatch(seed, (seed - 5137) % 4);
	if (!started.ok) throw new Error(started.reason);
	const teamScores = [score, score] as const;
	let hand = { ...started.match.hand, teamScores, turnStart: { ...started.match.hand.turnStart, teamScores } };
	for (const row of group) {
		if (hand.phase !== row.phase || hand.outcome !== null) throw new Error("phase mismatch");
		const deadline = performance.now() + 30000;
		const expired = () => performance.now() >= deadline;
		const actions = modernPlayableActions(hand, expired);
		if (expired()) throw new Error(`ranking timed out at ${seed}:${row.decision}`);
		const scored = actions.map((action) => ({
			key: modernActionKey(hand, action),
			features: modernPriorFeatures(hand, action),
		}));
		const top = (wildSpent: number) => {
			const weights = { ...MODERN_PRIOR_WEIGHTS, discardPair: 25, wildSpent };
			const entries = scored.map(({ key, features }) => ({ key, value: modernPriorValue(features, weights) }));
			const best = Math.max(...entries.map(({ value }) => value));
			return entries.filter(({ value }) => value === best).map(({ key }) => key).sort();
		};
		const incumbent = JSON.stringify(top(10));
		const changed = Object.fromEntries([-20, 0, 25, 50, 100].map((weight) => [weight, JSON.stringify(top(weight)) !== incumbent]));
		process.stdout.write(`${JSON.stringify({ seed, score, decision: row.decision, phase: hand.phase, actions: actions.length, varies: new Set(scored.map(({ features }) => features.wildSpent)).size > 1, changed })}\n`);
		const action = modernSearchActions(hand, expired).find((option) => modernActionKey(hand, option) === row.baselineAction);
		if (expired()) throw new Error(`reconstruction timed out at ${seed}:${row.decision}`);
		if (!action) throw new Error(`missing recorded action at ${seed}:${row.decision}`);
		const applied = modernApplyAction(hand, hand.turn, action);
		if (!applied.ok) throw new Error(applied.reason);
		hand = applied.hand;
	}
	if (!hand.outcome) throw new Error("unfinished reconstructed trajectory");
}
