import { buildDecks } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/cards.ts";
import { modernApplyAction, modernNewHand } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-hand.ts";
import { observeModern } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-inference.ts";
import { chooseModernPosition } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-search.ts";

const dealt = modernNewHand({ seed: 1, dealer: 3, teamScores: [0, 0] });
if (!dealt.ok) throw new Error(dealt.reason);
const deck = buildDecks();
const get = (id: string) => {
	const card = deck.find((item) => item.id === id);
	if (!card) throw new Error(`missing ${id}`);
	return card;
};
const kings = deck.filter((card) => card.rank === "K").slice(0, 7);
const queens = deck.filter((card) => card.rank === "Q").slice(0, 7);
const excluded = ["0-2C", "0-2D", "0-4C", ...kings.map((card) => card.id), ...queens.map((card) => card.id)];
const others = deck.filter((card) => !excluded.includes(card.id) && card.rank !== "3").slice(0, 33);
const occupied = [...excluded, ...others.map((card) => card.id)];
const start = {
	...dealt.hand.turnStart,
	hands: [[get("0-2C")], others.slice(0, 11), others.slice(11, 22), others.slice(22)] as const,
	stock: [get("0-2D"), ...deck.filter((card) => !occupied.includes(card.id))],
	pile: [get("0-4C")],
	teams: [{ opened: true, threes: [], melds: [
		{ id: "kings", kind: "natural" as const, rank: "K" as const, cards: kings },
		{ id: "queens", kind: "natural" as const, rank: "Q" as const, cards: queens },
	] }, { opened: false, threes: [], melds: [] }] as const,
};
const hand = { ...start, turnStart: start, undo: [] };
const drawn = modernApplyAction(hand, 0, { type: "draw" });
if (!drawn.ok) throw new Error(drawn.reason);
const discard = modernApplyAction(drawn.hand, 0, { type: "discard", card: "0-2C" });
const fallback = await chooseModernPosition(observeModern(drawn.hand, 0), { timeMs: 0 });
console.log(JSON.stringify({ phase: drawn.hand.phase, legalDiscard: discard.ok, fallback: fallback.action ?? null }));
