import { buildDecks } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/cards.ts";
import { modernStartMatch } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-match.ts";
import { modernApplyAction } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-hand.ts";
import { mulberry32 } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/random.ts";
import { cardFace } from "/home/dvolgyes/workspace/open_canasta-bot/src/game/canasta-history.ts";
import { recordModernTransfer, type ModernPublicHistory } from "/home/dvolgyes/workspace/open_canasta-bot/src/game/modern-history.ts";
import { inferModern, observeModern } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-inference.ts";
import { chooseModernPosition } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-search.ts";
import { modernActionKey } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-actions.ts";

const faceRanks = new Map(buildDecks().map((card) => [cardFace(card), card.rank]));
for (const score of [0, 3000, 5000]) for (let deal = 0; deal < 5; deal++) {
	const seed = 8137 + deal;
	const started = modernStartMatch(seed, deal % 4);
	if (!started.ok) throw new Error(started.reason);
	const teamScores = [score, score] as const;
	let hand = { ...started.match.hand, teamScores, turnStart: { ...started.match.hand.turnStart, teamScores } };
	let history: ModernPublicHistory | undefined;
	let decision = 0;
	while (decision < 300 && hand.outcome === null) {
		const observation = observeModern(hand, hand.turn, history);
		const belief = inferModern(observation.view, hand.turn, history);
		const next = (hand.turn + 1) % 4;
		const bounds = belief.players[next];
		if (!bounds) throw new Error("missing next-player bounds");
		const knownByRank = new Map<string, number>();
		for (const [face, count] of Object.entries(bounds.minimum)) {
			const rank = faceRanks.get(face);
			if (!rank) throw new Error(`unknown face ${face}`);
			knownByRank.set(rank, (knownByRank.get(rank) ?? 0) + count);
		}
		const riskyFaces = hand.phase === "play" ? [...new Set(hand.hands[hand.turn].filter((card) =>
			(knownByRank.get(card.rank) ?? 0) >= 2 && modernApplyAction(hand, hand.turn, { type: "discard", card: card.id }).ok,
		).map(cardFace))].sort() : [];
		const result = await chooseModernPosition(observation, {
			timeMs: 30000, maxIterations: 2, maxDepth: 3, rng: mulberry32(12000 + deal * 1000 + decision),
		});
		if (!result.action || result.iterations !== 2) throw new Error("missing action or simulation budget");
		const key = modernActionKey(hand, result.action);
		const discarded = result.action.type === "discard" ? hand.hands[hand.turn].find((card) => card.id === result.action?.card) : undefined;
		if (result.action.type === "discard" && !discarded) throw new Error("discard missing from actor hand");
		console.log(JSON.stringify({ score, seed, decision, phase: hand.phase, nextPlayer: next, knownRanks: [...knownByRank].filter(([, n]) => n >= 2).sort(), riskyFaces, baselineAction: key, baselineDiscardedRisk: discarded ? riskyFaces.includes(cardFace(discarded)) : false, iterations: result.iterations }));
		const applied = modernApplyAction(hand, hand.turn, result.action);
		if (!applied.ok) throw new Error(applied.reason);
		history = recordModernTransfer(history, hand, applied.hand);
		hand = applied.hand;
		decision++;
	}
	if (hand.outcome === null) throw new Error(`hand ${seed} exceeded action cap`);
}
