import { readFileSync, readdirSync, writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";
import { modernStudyPlan, parseModernStudyConfig } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/research/modern-study.ts";

const existing = new Set<number>();
for (const path of readFileSync("/tmp/open-canasta-all-pair-files.txt", "utf8").trim().split("\n").filter(Boolean)) {
	const record = JSON.parse(readFileSync(path, "utf8"));
	if (typeof record.plan?.seed === "number") existing.add(record.plan.seed);
}
const files = ["docs/modern-pair-confirm-handcrafted.json", "docs/modern-pair-confirm-zero.json", "docs/modern-pair-pile-heldout-config.json", "docs/modern-pair-retention-heldout-handcrafted.json", "docs/modern-pair-retention-heldout-zero.json", ...["docs/modern-pair-pile-grid-configs", "docs/modern-pair-retention-grid-configs"].flatMap((dir) => readdirSync(dir).map((name) => join(dir, name)))];
for (const path of files) {
	const parsed = parseModernStudyConfig(JSON.parse(readFileSync(path, "utf8")));
	if (!parsed.ok) throw new Error(parsed.reason);
	for (let i = 0; i < parsed.config.pairs; i++) existing.add(modernStudyPlan(parsed.config, i, 0).seed);
}
for (let seed = 27000; seed <= 27011; seed++) existing.add(seed);
for (let seed = 28000; seed <= 28023; seed++) existing.add(seed);
const template = JSON.parse(readFileSync("docs/modern-pair-retention-grid-configs/pos25-0.json", "utf8"));
const directory = "docs/modern-retention-eight-hand-configs";
mkdirSync(directory, { recursive: true });
const planned = new Set<number>();
for (const [score, split] of [[0, 0], [3000, 1], [5000, 2]] as const) {
	const input = { ...template, seed: 9913, split, pairs: 4, simulations: 8, initialTeamScore: score };
	const parsed = parseModernStudyConfig(input);
	if (!parsed.ok) throw new Error(parsed.reason);
	for (let pair = 0; pair < 4; pair++) {
		const seed = modernStudyPlan(parsed.config, pair, 0).seed;
		if (existing.has(seed) || planned.has(seed)) throw new Error(`duplicate deal seed ${seed}`);
		planned.add(seed);
	}
	writeFileSync(`${directory}/${score}.json`, `${JSON.stringify(input, null, "\t")}\n`);
}
if (planned.size !== 12 || existing.size < 1000) throw new Error("seed check incomplete");
console.log(JSON.stringify({ existingSeeds: existing.size, distinctNewSeeds: planned.size }));
