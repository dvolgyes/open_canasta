import { readFileSync } from "node:fs";
import { modernResearchAgent, playModernMatch } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/research/modern-arena.ts";
import { modernStudyPlan, parseModernStudyConfig } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/research/modern-study.ts";

const input = JSON.parse(readFileSync("/home/dvolgyes/workspace/open_canasta-bot/docs/modern-pair-threat-grid-configs/pos50-0.json", "utf8"));
const parsed = parseModernStudyConfig(input);
if (!parsed.ok) throw new Error(parsed.reason);
const config = parsed.config;
const budget = { simulations: config.simulations, depth: config.depth, timeMs: config.timeMs };
const agents = {
	a: modernResearchAgent({ ...budget, priorWeights: config.a, pairThreatV1Weight: config.aPairThreatV1Weight }),
	b: modernResearchAgent({ ...budget, priorWeights: config.b }),
};
const result = await playModernMatch(modernStudyPlan(config, 0, 0), (_seat, policy) => agents[policy]);
if (result.reason !== "hand cap" || result.deadlineStops !== 0) throw new Error("invalid profiled hand");
console.log(JSON.stringify({ actions: result.actions, simulations: result.simulations, deadlineStops: result.deadlineStops }));
