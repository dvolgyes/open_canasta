import { isWild } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/cards.ts";
import { teamOf } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/hand.ts";
import { modernNewHand, modernApplyAction } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-hand.ts";
import { mulberry32 } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/random.ts";
import { recordModernTransfer, type ModernPublicHistory } from "/home/dvolgyes/workspace/open_canasta-bot/src/game/modern-history.ts";
import { inferModern, observeModern } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-inference.ts";
import { modernPairThreatV1 } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-pair-threat-prior.ts";
import { chooseModernPosition } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-search.ts";
import { modernPlayableActions } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-actions.ts";

for (let deal = 0; deal < 1; deal++) {
	const seed = 28000 + deal;
	const score = [0, 3000, 5000][Math.floor(deal / 8)];
	const started = modernNewHand({ seed, dealer: (deal % 4) as 0 | 1 | 2 | 3, teamScores: [score, score] });
	if (!started.ok) throw new Error(started.reason);
	let hand = started.hand;
	let history: ModernPublicHistory | undefined;
	let decision = 0;
	while (decision < 300 && hand.outcome === null) {
		const seat = hand.turn, next = ((seat + 1) % 4) as 0 | 1 | 2 | 3;
		const observation = observeModern(hand, seat, history);
		const actions = modernPlayableActions(hand, () => false);
		const rankActions = new Map();
		for (const action of actions) {
			if (action.type !== "discard") continue;
			const card = observation.view.hand.find((item) => item.id === action.card);
			if (!card) throw new Error("missing discard");
			const closed = observation.view.teams.some((team) => team.melds.some((meld) => meld.kind === "natural" && meld.rank === card.rank && meld.cards.length === 7));
			const existing = observation.view.teams[teamOf(next)].melds.find((meld) => meld.kind === "natural" && meld.rank === card.rank);
			if (!isWild(card) && card.rank !== "3" && !closed && (!existing || existing.cards.length <= 4)) rankActions.set(card.rank, action);
		}
		if (rankActions.size >= 2) {
			const ranks = [...rankActions.keys()].sort();
			const pick = mulberry32(900000 + deal * 1000 + decision)();
			const rank = ranks[Math.floor(pick * ranks.length)];
			const action = rankActions.get(rank);
			const belief = inferModern(observation.view, seat, history);
			const estimate = -modernPairThreatV1(observation.view, belief, action);
			const actual = [...hand.hands[next], ...hand.bonuses[next]].filter((card) => card.rank === rank).length >= 2 ? 1 : 0;
			console.log(JSON.stringify({ seed, score, dealer: deal % 4, decision, rank, estimate, actual }));
		}
		const chosen = await chooseModernPosition(observation, {
			timeMs: 30000, maxIterations: 2, maxDepth: 3,
			rng: mulberry32(120000 + deal * 1000 + decision),
		});
		if (!chosen.action || chosen.iterations !== 2) throw new Error("search did not meet its budget");
		const applied = modernApplyAction(hand, seat, chosen.action);
		if (!applied.ok) throw new Error(applied.reason);
		history = recordModernTransfer(history, hand, applied.hand);
		hand = applied.hand;
		decision++;
	}
	if (hand.outcome === null) throw new Error(`hand ${seed} exceeded action cap`);
}
