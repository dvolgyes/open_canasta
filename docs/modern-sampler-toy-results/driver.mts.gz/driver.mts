import { sampleCards, type CardBelief } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/card-knowledge.ts";
import { mulberry32 } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/random.ts";

const faces = ["A", "B", "C"];
const maxima = [
	{ A: 4, B: 0, C: 4 },
	{ A: 4, B: 4, C: 0 },
	{ A: 0, B: 4, C: 4 },
	{ A: 4, B: 4, C: 4 },
];
const belief: CardBelief = {
	faces,
	remaining: { A: 4, B: 4, C: 4 },
	players: maxima.map((maximum) => ({
		count: 3,
		minimum: { A: 0, B: 0, C: 0 },
		maximum,
	})),
};
const factorial = [1, 1, 2, 6];
const exact = [0, 0, 0, 0];
function enumerate(row: number, remaining: number[], weight: number, firstA: number): void {
	if (row === 4) {
		if (remaining.every((n) => n === 0)) exact[firstA] += weight;
		return;
	}
	for (let a = 0; a <= 3; a++) for (let b = 0; b <= 3 - a; b++) {
		const c = 3 - a - b;
		const counts = [a, b, c];
		if (counts.some((n, i) => n > remaining[i] || n > maxima[row][faces[i]])) continue;
		const arrangements = 6 / (factorial[a] * factorial[b] * factorial[c]);
		enumerate(row + 1, remaining.map((n, i) => n - counts[i]), weight * arrangements, row === 0 ? a : firstA);
	}
}
enumerate(0, [4, 4, 4], 1, 0);
const valid = exact.reduce((sum, n) => sum + n, 0);
const total = 34650;
const samples = [0, 0, 0, 0];
const rng = mulberry32(2026);
for (let i = 0; i < 20000; i++) {
	const allocation = sampleCards(belief, rng);
	const a = allocation[0].filter((face) => face === "A").length;
	samples[a]++;
}
console.log(JSON.stringify({
	totalPhysicalFaceSequences: total,
	validSequences: valid,
	acceptanceProbability: valid / total,
	independentEightFailureProbability: (1 - valid / total) ** 8,
	exactFirstRowA: exact.map((n) => n / valid),
	sampleSize: 20000,
	sampledFirstRowA: samples.map((n) => n / 20000),
	maxAbsoluteDifference: Math.max(...samples.map((n, i) => Math.abs(n / 20000 - exact[i] / valid))),
}));
