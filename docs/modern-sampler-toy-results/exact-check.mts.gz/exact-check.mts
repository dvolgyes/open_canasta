let total = 0;
let valid = 0;
const counts = [0, 0, 0, 0];
for (let a = 0; a < 4096; a++) {
	if (a.toString(2).replaceAll("0", "").length !== 4) continue;
	for (let b = 0; b < 4096; b++) {
		if ((a & b) !== 0 || b.toString(2).replaceAll("0", "").length !== 4) continue;
		total++;
		let allowed = true;
		for (let i = 0; i < 3; i++) if (b & (1 << i)) allowed = false;
		for (let i = 3; i < 6; i++) if (!((a | b) & (1 << i))) allowed = false;
		for (let i = 6; i < 9; i++) if (a & (1 << i)) allowed = false;
		if (!allowed) continue;
		valid++;
		let firstA = 0;
		for (let i = 0; i < 3; i++) if (a & (1 << i)) firstA++;
		counts[firstA]++;
	}
}
console.log(JSON.stringify({ total, valid, counts }));
