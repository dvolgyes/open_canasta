import { buildDecks, isWild } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/cards.ts";
import { teamOf } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/hand.ts";
import { modernNewHand, modernApplyAction } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-hand.ts";
import { mulberry32 } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/random.ts";
import { cardFace } from "/home/dvolgyes/workspace/open_canasta-bot/src/game/canasta-history.ts";
import { recordModernTransfer, type ModernPublicHistory } from "/home/dvolgyes/workspace/open_canasta-bot/src/game/modern-history.ts";
import { inferModern, observeModern } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-inference.ts";
import { chooseModernPosition } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-search.ts";
import { modernActionKey, modernPlayableActions } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-actions.ts";
import { MODERN_PRIOR_WEIGHTS, modernPriorFeatures, modernPriorValue } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-prior.ts";
import { relaxedPairProbability } from "/tmp/open-canasta-relaxed-pair.mts";
import { relaxedPairChance } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/relaxed-card-pair.ts";

const deck = buildDecks();
for (let deal = 0; deal < 12; deal++) {
	const seed = 27000 + deal;
	const score = [0, 3000, 5000][Math.floor(deal / 4)];
	const started = modernNewHand({ seed, dealer: (deal % 4) as 0 | 1 | 2 | 3, teamScores: [score, score] });
	if (!started.ok) throw new Error(started.reason);
	let hand = started.hand;
	let history: ModernPublicHistory | undefined;
	let decision = 0;
	while (decision < 300 && hand.outcome === null) {
		const seat = hand.turn;
		const observation = observeModern(hand, seat, history);
		const actions = modernPlayableActions(hand, () => false);
		const belief = actions.some((action) => action.type === "discard") ? inferModern(observation.view, seat, history) : undefined;
		const next = ((seat + 1) % 4) as 0 | 1 | 2 | 3;
		const risks = new Map<string, number>();
		const scored = actions.map((action) => {
			let risk = 0;
			if (action.type === "discard") {
				const card = observation.view.hand.find((item) => item.id === action.card);
				if (!card || !belief) throw new Error("missing discard or belief");
				const closed = observation.view.teams.some((team) => team.melds.some((meld) => meld.kind === "natural" && meld.rank === card.rank && meld.cards.length === 7));
				const existing = observation.view.teams[teamOf(next)].melds.find((meld) => meld.kind === "natural" && meld.rank === card.rank);
				if (!isWild(card) && card.rank !== "3" && !closed && (!existing || existing.cards.length <= 4)) {
					if (!risks.has(card.rank)) {
						const faces = new Set(deck.filter((item) => item.rank === card.rank).map(cardFace));
						const previous = relaxedPairProbability(belief, [next, next + 4], faces);
						const current = relaxedPairChance(belief, [next, next + 4], [...faces]);
						if (Math.abs(previous - current) > 1e-12) throw new Error(`pair-model mismatch: ${previous} vs ${current}`);
						risks.set(card.rank, current);
					}
					risk = risks.get(card.rank) ?? 0;
				}
			}
			return { key: modernActionKey(hand, action), features: modernPriorFeatures(hand, action), risk };
		});
		const top = (weight: number) => {
			const scores = scored.map(({ key, features, risk }) => ({ key, value: modernPriorValue(features, MODERN_PRIOR_WEIGHTS, -weight * risk) }));
			const best = Math.max(...scores.map((entry) => entry.value));
			return scores.filter((entry) => entry.value === best).map((entry) => entry.key).sort();
		};
		const baseline = top(0);
		const changed = Object.fromEntries([25, 50, 100].map((weight) => [weight, JSON.stringify(top(weight)) !== JSON.stringify(baseline)]));
		console.log(JSON.stringify({ seed, score, dealer: deal % 4, decision, phase: hand.phase, actions: actions.length, changed }));
		const chosen = await chooseModernPosition(observation, {
			timeMs: 30000, maxIterations: 2, maxDepth: 3,
			rng: mulberry32(94000 + deal * 1000 + decision),
		});
		if (!chosen.action || chosen.iterations !== 2) throw new Error("search did not meet its budget");
		const applied = modernApplyAction(hand, seat, chosen.action);
		if (!applied.ok) throw new Error(applied.reason);
		history = recordModernTransfer(history, hand, applied.hand);
		hand = applied.hand;
		decision++;
	}
	if (hand.outcome === null) throw new Error(`hand ${seed} exceeded action cap`);
}
