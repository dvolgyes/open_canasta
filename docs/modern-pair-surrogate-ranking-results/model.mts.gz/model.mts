import type { CardBelief } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/card-knowledge.ts";

/** Hypergeometric tail under a relaxed model that uniformly allocates remaining physical cards. */
export function relaxedPairProbability(belief: CardBelief, targetRows: readonly number[], faces: ReadonlySet<string>): number {
	const rows = targetRows.map((index) => {
		const row = belief.players[index];
		if (!row) throw new Error("missing target row");
		return row;
	});
	const known = rows.reduce((sum, row) => sum + [...faces].reduce((n, face) => n + (row.minimum[face] ?? 0), 0), 0);
	const maximum = rows.reduce((sum, row) => sum + [...faces].reduce((n, face) => n + (row.maximum[face] ?? 0), 0), 0);
	if (maximum < 2) return 0;
	if (known >= 2) return 1;
	const free = belief.faces.map((face) => ({
		face,
		count: (belief.remaining[face] ?? 0) - belief.players.reduce((sum, row) => sum + (row.minimum[face] ?? 0), 0),
	}));
	if (free.some((item) => !Number.isSafeInteger(item.count) || item.count < 0)) throw new Error("invalid free card inventory");
	const population = free.reduce((sum, item) => sum + item.count, 0);
	const successes = free.reduce((sum, item) => sum + (faces.has(item.face) ? item.count : 0), 0);
	const draws = rows.reduce((sum, row) => sum + row.count - belief.faces.reduce((n, face) => n + (row.minimum[face] ?? 0), 0), 0);
	if (!Number.isSafeInteger(draws) || draws < 0 || draws > population) throw new Error("invalid unknown slots");
	if (draws === 0 || successes === 0) return 0;
	let p0 = 1, p1 = 0;
	for (let i = 0; i < draws; i++) {
		const remaining = population - i;
		p1 = p1 * Math.max(0, population - successes - i + 1) / remaining + p0 * successes / remaining;
		p0 = p0 * Math.max(0, population - successes - i) / remaining;
	}
	return Math.max(0, Math.min(1, 1 - p0 - (known === 0 ? p1 : 0)));
}
