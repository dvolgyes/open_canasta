import { relaxedPairProbability } from "/tmp/open-canasta-relaxed-pair.mts";
const choose = (n: number, k: number): number => {
	if (k < 0 || k > n) return 0;
	let value = 1;
	for (let i = 1; i <= k; i++) value = value * (n - i + 1) / i;
	return value;
};
let cases = 0;
for (let population = 2; population <= 10; population++) for (let successes = 0; successes <= population; successes++) for (let draws = 0; draws <= population; draws++) {
	const rows = [
		{ count: draws, minimum: { A: 0, B: 0 }, maximum: { A: successes, B: population - successes } },
		{ count: population - draws, minimum: { A: 0, B: 0 }, maximum: { A: successes, B: population - successes } },
	];
	const belief = { faces: ["A", "B"], remaining: { A: successes, B: population - successes }, players: rows };
	const expected = Array.from({ length: draws + 1 }, (_, k) => k >= 2 ? choose(successes, k) * choose(population - successes, draws - k) / choose(population, draws) : 0).reduce((a, b) => a + b, 0);
	const actual = relaxedPairProbability(belief, [0], new Set(["A"]));
	if (Math.abs(expected - actual) > 1e-12) throw new Error(`mismatch for ${population}, ${successes}, ${draws}: ${actual} vs ${expected}`);
	cases++;
}
const withKnown = {
	faces: ["A", "B"], remaining: { A: 2, B: 2 },
	players: [
		{ count: 2, minimum: { A: 1, B: 0 }, maximum: { A: 2, B: 2 } },
		{ count: 2, minimum: { A: 0, B: 0 }, maximum: { A: 2, B: 2 } },
	],
};
if (Math.abs(relaxedPairProbability(withKnown, [0], new Set(["A"])) - 1 / 3) > 1e-12) throw new Error("known-copy mismatch");
const forced = { ...withKnown, players: [{ ...withKnown.players[0], minimum: { A: 2, B: 0 } }, withKnown.players[1]] };
if (relaxedPairProbability(forced, [0], new Set(["A"])) !== 1) throw new Error("guaranteed-pair mismatch");
const impossible = { ...withKnown, players: [{ ...withKnown.players[0], maximum: { A: 1, B: 2 } }, withKnown.players[1]] };
if (relaxedPairProbability(impossible, [0], new Set(["A"])) !== 0) throw new Error("impossible-pair mismatch");
console.log(JSON.stringify({ cases, matched: true }));
