function tail(pairCount, outcomeProbabilities, minimumWins) {
	let distribution = [1];
	for (let i = 0; i < pairCount; i++) {
		const next = Array(distribution.length + 2).fill(0);
		for (let wins = 0; wins < distribution.length; wins++) {
			for (let result = 0; result < 3; result++) {
				next[wins + result] += distribution[wins] * outcomeProbabilities[result];
			}
		}
		distribution = next;
	}
	return distribution.slice(minimumWins).reduce((sum, probability) => sum + probability, 0);
}

console.log(JSON.stringify({
	model: { independentIdenticalPairs: true, probabilitiesForZeroOneTwoWins: [0.14, 0.50, 0.36] },
	pairs: 200,
	probabilityOf239Wins: tail(200, [0.14, 0.50, 0.36], 239),
	probabilityOf278Wins: tail(200, [0.14, 0.50, 0.36], 278),
}));
