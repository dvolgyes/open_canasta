import { mkdirSync, writeFileSync } from "node:fs";
import { MODERN_PRIOR_WEIGHTS } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-prior.ts";
import { modernStudyPlan, parseModernStudyConfig } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/research/modern-study.ts";

const out = "docs/modern-discard-risk-grid-configs";
mkdirSync(out, { recursive: true });
for (const weight of [-100, -50, -25, 25, 50, 100]) {
	for (const [band, score] of [0, 3000, 5000].entries()) {
		const config = {
			version: 1, seed: 1307, split: 29 + band, pairs: 4, maxHands: 1,
			maxActionsPerHand: 300, simulations: 2, timeMs: 30000, depth: 3,
			initialTeamScore: score, a: MODERN_PRIOR_WEIGHTS, b: MODERN_PRIOR_WEIGHTS,
			aDiscardRiskV1Weight: weight,
		};
		const parsed = parseModernStudyConfig(config);
		if (!parsed.ok) throw new Error(parsed.reason);
		const label = weight < 0 ? `neg${-weight}` : `pos${weight}`;
		writeFileSync(`${out}/${label}-${score}.json`, `${JSON.stringify(config, null, "\t")}\n`, { flag: "wx" });
	}
}
const plans = [0, 3000, 5000].flatMap((score, band) => {
	const parsed = parseModernStudyConfig({ version: 1, seed: 1307, split: 29 + band, pairs: 4, maxHands: 1, maxActionsPerHand: 300, simulations: 2, timeMs: 30000, depth: 3, initialTeamScore: score, a: MODERN_PRIOR_WEIGHTS, b: MODERN_PRIOR_WEIGHTS });
	if (!parsed.ok) throw new Error(parsed.reason);
	return Array.from({ length: 4 }, (_, index) => modernStudyPlan(parsed.config, index, 0));
});
if (new Set(plans.map((plan) => plan.seed)).size !== 12) throw new Error("study seeds are not distinct");
console.log(JSON.stringify({ configs: 18, distinctDeals: plans.length }));
