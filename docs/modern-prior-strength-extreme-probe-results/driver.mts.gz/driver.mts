import { modernNewHand, modernApplyAction } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-hand.ts";
import { observeModern } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-inference.ts";
import { chooseModernPosition } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-search.ts";
import { modernActionKey } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-actions.ts";
import { mulberry32 } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/random.ts";

for (let seed = 1; seed <= 20; seed++) {
	const dealt = modernNewHand({ seed, dealer: 3, teamScores: [0, 0] });
	if (!dealt.ok) throw new Error(dealt.reason);
	const drawn = modernApplyAction(dealt.hand, 0, { type: "draw" });
	if (!drawn.ok) throw new Error(drawn.reason);
	const observation = observeModern(drawn.hand, 0);
	const options = { timeMs: 30000, maxIterations: 8, maxDepth: 8 };
	const base = await chooseModernPosition(observation, { ...options, priorWeight: 0, rng: mulberry32(91) });
	const strong = await chooseModernPosition(observation, { ...options, priorWeight: 100, rng: mulberry32(91) });
	if (!base.action || !strong.action) throw new Error("missing action");
	if (base.iterations !== 8 || strong.iterations !== 8) throw new Error("budget missed");
	const baseKey = modernActionKey(drawn.hand, base.action);
	const strongKey = modernActionKey(drawn.hand, strong.action);
	console.log(JSON.stringify({ seed, baseKey, strongKey }));
}
