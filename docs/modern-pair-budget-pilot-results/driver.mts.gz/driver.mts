import { MODERN_PRIOR_WEIGHTS } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-prior.ts";
import { modernResearchAgent, playModernMatch, type ModernResearchAgent } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/research/modern-arena.ts";
import { modernStudyPlan, parseModernStudyConfig } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/research/modern-study.ts";

const parsed = parseModernStudyConfig({ version: 1, seed: 5507, split: 3, pairs: 1, maxHands: 1, maxActionsPerHand: 300, simulations: 2, timeMs: 30000, depth: 3, initialTeamScore: 3000, a: MODERN_PRIOR_WEIGHTS, b: MODERN_PRIOR_WEIGHTS, aPairThreatV1Weight: 100 });
if (!parsed.ok) throw new Error(parsed.reason);
const policies = {
	a: modernResearchAgent({ priorWeights: MODERN_PRIOR_WEIGHTS, pairThreatV1Weight: 100, simulations: 2, timeMs: 30000, depth: 3 }),
	b: modernResearchAgent({ priorWeights: MODERN_PRIOR_WEIGHTS, simulations: 2, timeMs: 30000, depth: 3 }),
};
let decisions = 0, misses = 0, slowestMs = 0;
const result = await playModernMatch(modernStudyPlan(parsed.config, 0, 0), (_seat, name): ModernResearchAgent => ({
	async decide(observation, context) {
		const start = performance.now();
		const decision = await policies[name].decide(observation, context);
		slowestMs = Math.max(slowestMs, performance.now() - start);
		if (decision.ok) {
			decisions++;
			misses += Number(decision.deadlineStopped || decision.simulations !== 2);
		}
		return decision;
	},
}));
if (result.reason !== "hand cap" && result.reason !== "scenario hand") throw new Error(`unexpected hand result: ${result.reason}`);
if (decisions !== result.actions || misses !== 0) throw new Error("missed decision budget");
console.log(JSON.stringify({ decisions, misses, slowestMs, reason: result.reason }));
