import { readFileSync } from "node:fs";
import { modernStartMatch } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-match.ts";
import { modernApplyAction } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-hand.ts";
import { mulberry32 } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/random.ts";
import { cardFace } from "/home/dvolgyes/workspace/open_canasta-bot/src/game/canasta-history.ts";
import { recordModernTransfer, type ModernPublicHistory } from "/home/dvolgyes/workspace/open_canasta-bot/src/game/modern-history.ts";
import { observeModern } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-inference.ts";
import { chooseModernPosition } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-search.ts";
import { modernActionKey, modernPlayableActions } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-actions.ts";

const records = readFileSync("/tmp/open-canasta-known-pair-probe.jsonl", "utf8").trim().split("\n").map((line) => JSON.parse(line)).filter((row) => row.score === 3000 && row.seed === 8137);
const started = modernStartMatch(8137, 0);
if (!started.ok) throw new Error(started.reason);
const teamScores = [3000, 3000] as const;
let hand = { ...started.match.hand, teamScores, turnStart: { ...started.match.hand.turnStart, teamScores } };
let history: ModernPublicHistory | undefined;
for (let decision = 0; decision <= 45; decision++) {
	const observation = observeModern(hand, hand.turn, history);
	const result = await chooseModernPosition(observation, { timeMs: 30000, maxIterations: 2, maxDepth: 3, rng: mulberry32(12000 + decision) });
	if (!result.action || result.iterations !== 2 || modernActionKey(hand, result.action) !== records[decision]?.baselineAction) throw new Error(`trajectory mismatch at ${decision}`);
	if (decision === 44) {
		const aware = await chooseModernPosition(observation, { timeMs: 30000, maxIterations: 2, maxDepth: 3, knownPairV1Weight: 50, rng: mulberry32(12000 + decision) });
		if (!aware.action || aware.iterations !== 2) throw new Error("aware search missed budget");
		const discards = hand.hands[hand.turn].flatMap((card) => {
			const applied = modernApplyAction(hand, hand.turn, { type: "discard", card: card.id });
			if (!applied.ok) return [];
			const pileAvailable = modernPlayableActions(applied.hand).some((action) => action.type === "take-pile");
			return [{ face: cardFace(card), rank: card.rank, nextCanTakePile: pileAvailable }];
		});
		console.log(JSON.stringify({ decision, actor: hand.turn, handSize: hand.hands[hand.turn].length, pileSize: hand.pile.length, legalDiscards: discards, baselineAction: modernActionKey(hand, result.action), awareAction: modernActionKey(hand, aware.action), awareIterations: aware.iterations }));
	}
	const applied = modernApplyAction(hand, hand.turn, result.action);
	if (!applied.ok) throw new Error(applied.reason);
	history = recordModernTransfer(history, hand, applied.hand);
	hand = applied.hand;
}
