import { buildDecks, isWild } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/cards.ts";
import { teamOf } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/hand.ts";
import { modernNewHand, modernApplyAction } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-hand.ts";
import { mulberry32 } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/random.ts";
import { cardFace } from "/home/dvolgyes/workspace/open_canasta-bot/src/game/canasta-history.ts";
import { recordModernTransfer, type ModernPublicHistory } from "/home/dvolgyes/workspace/open_canasta-bot/src/game/modern-history.ts";
import { sampleCards } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/card-knowledge.ts";
import { inferModern, observeModern } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-inference.ts";
import { chooseModernPosition } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-search.ts";
import { modernPlayableActions } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-actions.ts";
import { relaxedPairProbability } from "/tmp/open-canasta-relaxed-pair.mts";

const deck = buildDecks();
for (let deal = 0; deal < 12; deal++) {
	const seed = 27000 + deal;
	const score = [0, 3000, 5000][Math.floor(deal / 4)];
	const started = modernNewHand({ seed, dealer: (deal % 4) as 0 | 1 | 2 | 3, teamScores: [score, score] });
	if (!started.ok) throw new Error(started.reason);
	let hand = started.hand;
	let history: ModernPublicHistory | undefined;
	let decision = 0, target = 0;
	const thresholds = [5, 25, 45];
	while (decision < 300 && hand.outcome === null) {
		const seat = hand.turn;
		const observation = observeModern(hand, seat, history);
		if (target < thresholds.length && decision >= thresholds[target]) {
			const next = ((seat + 1) % 4) as 0 | 1 | 2 | 3;
			const actions = modernPlayableActions(hand, () => false);
			const ranks = [...new Set(actions.flatMap((action) => {
				if (action.type !== "discard") return [];
				const card = observation.view.hand.find((item) => item.id === action.card);
				if (!card) throw new Error("missing discard");
				const closed = observation.view.teams.some((team) => team.melds.some((meld) => meld.kind === "natural" && meld.rank === card.rank && meld.cards.length === 7));
				const existing = observation.view.teams[teamOf(next)].melds.find((meld) => meld.kind === "natural" && meld.rank === card.rank);
				return !isWild(card) && card.rank !== "3" && !closed && (!existing || existing.cards.length <= 4) ? [card.rank] : [];
			}))].sort();
			if (ranks.length >= 2) {
				const belief = inferModern(observation.view, seat, history);
				const faces = ranks.map((rank) => new Set(deck.filter((item) => item.rank === rank).map(cardFace)));
				const estimates = faces.map((set) => relaxedPairProbability(belief, [next, next + 4], set));
				const wins = ranks.map(() => 0);
				const rng = mulberry32(60000 + deal * 1000 + target);
				for (let sample = 0; sample < 500; sample++) {
					const rows = sampleCards(belief, rng);
					const cards = [...rows[next], ...rows[next + 4]];
					for (let i = 0; i < faces.length; i++) if (cards.filter((face) => faces[i].has(face)).length >= 2) wins[i]++;
				}
				console.log(JSON.stringify({ seed, score, dealer: deal % 4, decision, threshold: thresholds[target], ranks, estimates, sampled: wins.map((count) => count / 500) }));
				target++;
			}
		}
		const chosen = await chooseModernPosition(observation, {
			timeMs: 30000, maxIterations: 2, maxDepth: 3,
			rng: mulberry32(94000 + deal * 1000 + decision),
		});
		if (!chosen.action || chosen.iterations !== 2) throw new Error("search did not meet its budget");
		const applied = modernApplyAction(hand, seat, chosen.action);
		if (!applied.ok) throw new Error(applied.reason);
		history = recordModernTransfer(history, hand, applied.hand);
		hand = applied.hand;
		decision++;
	}
	if (hand.outcome === null) throw new Error(`hand ${seed} exceeded action cap`);
	console.log(JSON.stringify({ seed, missingThresholds: thresholds.slice(target) }));
}
