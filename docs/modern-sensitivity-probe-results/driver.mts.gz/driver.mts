import { modernStartMatch } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-match.ts";
import { modernApplyAction } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-hand.ts";
import { mulberry32 } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/random.ts";
import { recordModernTransfer, type ModernPublicHistory } from "/home/dvolgyes/workspace/open_canasta-bot/src/game/modern-history.ts";
import { observeModern } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-inference.ts";
import { chooseModernPosition } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-search.ts";
import { modernActionKey } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-actions.ts";
import { MODERN_PRIOR_WEIGHTS } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-prior.ts";
import { readFileSync } from "node:fs";

const candidate = JSON.parse(readFileSync("docs/modern-hand-training-balanced-results/update-20.json", "utf8")).candidate;
const started = modernStartMatch(9137, 0);
if (!started.ok) throw new Error(started.reason);
let hand = started.match.hand;
let history: ModernPublicHistory | undefined;
for (let decision = 0; decision < 50 && hand.outcome === null; decision++) {
	const view = observeModern(hand, hand.turn, history);
	const options = { timeMs: 30000, maxIterations: 2, maxDepth: 3 };
	const baseline = await chooseModernPosition(view, {
		...options,
		priorWeights: MODERN_PRIOR_WEIGHTS,
		rng: mulberry32(2000 + decision),
	});
	const trained = await chooseModernPosition(view, {
		...options,
		priorWeights: candidate,
		rng: mulberry32(2000 + decision),
	});
	if (!baseline.action || !trained.action) throw new Error("missing action");
	console.log(JSON.stringify({
		decision,
		phase: hand.phase,
		baselineIterations: baseline.iterations,
		trainedIterations: trained.iterations,
		baselineAction: modernActionKey(hand, baseline.action),
		trainedAction: modernActionKey(hand, trained.action),
	}));
	const applied = modernApplyAction(hand, hand.turn, baseline.action);
	if (!applied.ok) throw new Error(applied.reason);
	history = recordModernTransfer(history, hand, applied.hand);
	hand = applied.hand;
}
