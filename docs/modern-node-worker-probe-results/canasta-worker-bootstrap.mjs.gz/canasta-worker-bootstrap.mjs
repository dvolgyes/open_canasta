import { tsImport } from "/home/dvolgyes/workspace/open_canasta-bot/node_modules/tsx/dist/esm/api/index.mjs";

await tsImport("./canasta-worker-probe.mts", import.meta.url);
