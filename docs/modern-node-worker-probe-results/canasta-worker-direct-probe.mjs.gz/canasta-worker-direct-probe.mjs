import { Worker } from "node:worker_threads";
import { createRequire } from "node:module";
import { pathToFileURL } from "node:url";

const require = createRequire(`${process.cwd()}/package.json`);
const worker = new Worker(new URL("./canasta-worker-probe.mts", import.meta.url), {
	execArgv: ["--import", pathToFileURL(require.resolve("tsx")).href],
});
worker.on("message", (value) => console.log(JSON.stringify(value)));
worker.on("error", (error) => {
	console.error(error);
	process.exitCode = 1;
});
