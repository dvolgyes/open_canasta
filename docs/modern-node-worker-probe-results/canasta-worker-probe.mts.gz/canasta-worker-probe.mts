import { parentPort } from "node:worker_threads";
import { modernStartMatch } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-match.ts";

parentPort?.postMessage({ ok: modernStartMatch(42, 0).ok });
