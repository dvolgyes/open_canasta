import { Worker } from "node:worker_threads";

const worker = new Worker(new URL("./canasta-worker-bootstrap.mjs", import.meta.url));
worker.on("message", (value) => console.log(JSON.stringify(value)));
worker.on("error", (error) => {
	console.error(error);
	process.exitCode = 1;
});
