import { modernStartMatch } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-match.ts";
import { modernApplyAction } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-hand.ts";
import { teamOf } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/hand.ts";
import { mulberry32 } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/random.ts";
import { recordModernTransfer, type ModernPublicHistory } from "/home/dvolgyes/workspace/open_canasta-bot/src/game/modern-history.ts";
import { observeModern } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-inference.ts";
import { chooseModernPosition } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-search.ts";
import { modernActionKey, modernPlayableActions } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-actions.ts";
import { modernSevenBlockedV1 } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-seven-risk.ts";

for (const score of [0, 3000, 5000]) for (let deal = 0; deal < 5; deal++) {
	const seed = 7137 + deal;
	const started = modernStartMatch(seed, deal % 4);
	if (!started.ok) throw new Error(started.reason);
	const teamScores = [score, score] as const;
	let hand = { ...started.match.hand, teamScores, turnStart: { ...started.match.hand.turnStart, teamScores } };
	let history: ModernPublicHistory | undefined;
	let decision = 0;
	while (decision < 300 && hand.outcome === null) {
		const view = observeModern(hand, hand.turn, history);
		const options = { timeMs: 30000, maxIterations: 2, maxDepth: 3 };
		const baseline = await chooseModernPosition(view, { ...options, rng: mulberry32(8000 + deal * 1000 + decision) });
		const sevenAware = await chooseModernPosition(view, { ...options, sevenBlockedV1Weight: 100, rng: mulberry32(8000 + deal * 1000 + decision) });
		if (!baseline.action || !sevenAware.action) throw new Error("missing action");
		if (baseline.iterations !== 2 || sevenAware.iterations !== 2) throw new Error("missed simulation budget");
		const opposing = hand.teams[teamOf(hand.turn) === 0 ? 1 : 0];
		const fixed = opposing.melds.reduce((n, m) => n + (m.kind === "natural" && m.rank === "7" ? m.cards.length : 0), 0);
		const penalized = fixed < 2 ? 0 : modernPlayableActions(hand).filter((action) => modernSevenBlockedV1(hand, action) < 0).length;
		console.log(JSON.stringify({ score, seed, decision, phase: hand.phase, fixedOpposingSevens: fixed, penalized, baselineIterations: baseline.iterations, sevenIterations: sevenAware.iterations, baselineRootChoices: baseline.choices.length, baselineAction: modernActionKey(hand, baseline.action), sevenAction: modernActionKey(hand, sevenAware.action) }));
		const applied = modernApplyAction(hand, hand.turn, baseline.action);
		if (!applied.ok) throw new Error(applied.reason);
		history = recordModernTransfer(history, hand, applied.hand);
		hand = applied.hand;
		decision++;
	}
	if (hand.outcome === null) throw new Error(`hand ${seed} exceeded action cap`);
}
