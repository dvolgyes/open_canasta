import { modernNewHand, modernApplyAction } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-hand.ts";
import { mulberry32 } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/random.ts";
import { recordModernTransfer, type ModernPublicHistory } from "/home/dvolgyes/workspace/open_canasta-bot/src/game/modern-history.ts";
import { inferModern, observeModern } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-inference.ts";
import { chooseModernPosition } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-search.ts";
import { modernActionKey, modernPlayableActions } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-actions.ts";
import { modernPairThreatV1 } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-pair-threat-prior.ts";
import { MODERN_PRIOR_WEIGHTS, modernPriorFeatures, modernPriorValue } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-prior.ts";

for (let deal = 0; deal < 12; deal++) {
	const seed = 27000 + deal;
	const score = [0, 3000, 5000][Math.floor(deal / 4)];
	const started = modernNewHand({ seed, dealer: (deal % 4) as 0 | 1 | 2 | 3, teamScores: [score, score] });
	if (!started.ok) throw new Error(started.reason);
	let hand = started.hand;
	let history: ModernPublicHistory | undefined;
	let decision = 0;
	while (decision < 300 && hand.outcome === null) {
		const seat = hand.turn;
		const observation = observeModern(hand, seat, history);
		const actions = modernPlayableActions(hand, () => false);
		const belief = inferModern(observation.view, seat, history);
		const scored = actions.map((action) => ({
			key: modernActionKey(hand, action),
			features: modernPriorFeatures(hand, action),
			risk: modernPairThreatV1(observation.view, belief, action),
		}));
		const top = (weight: number) => {
			const entries = scored.map(({ key, features, risk }) => ({ key, value: modernPriorValue(features, MODERN_PRIOR_WEIGHTS, weight * risk) }));
			const best = Math.max(...entries.map((entry) => entry.value));
			return entries.filter((entry) => entry.value === best).map((entry) => entry.key).sort();
		};
		const scale = 1 + Math.min(hand.pile.length, 8) / 8;
		console.log(JSON.stringify({ seed, score, dealer: deal % 4, decision, phase: hand.phase, actions: actions.length, pileSize: hand.pile.length, changed: JSON.stringify(top(50)) !== JSON.stringify(top(50 * scale)) }));
		const chosen = await chooseModernPosition(observation, { timeMs: 30000, maxIterations: 2, maxDepth: 3, rng: mulberry32(94000 + deal * 1000 + decision) });
		if (!chosen.action || chosen.iterations !== 2) throw new Error("search did not meet its budget");
		const applied = modernApplyAction(hand, seat, chosen.action);
		if (!applied.ok) throw new Error(applied.reason);
		history = recordModernTransfer(history, hand, applied.hand);
		hand = applied.hand;
		decision++;
	}
	if (hand.outcome === null) throw new Error(`hand ${seed} exceeded action cap`);
}
