import { readFileSync, writeFileSync } from "node:fs";
import { modernStudyPlan, parseModernStudyConfig } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/research/modern-study.ts";

const files = readFileSync("/tmp/open-canasta-all-pair-files.txt", "utf8").trim().split("\n").filter(Boolean);
const existing = new Set<number>();
for (const path of files) {
	const record = JSON.parse(readFileSync(path, "utf8"));
	if (typeof record.plan?.seed === "number") existing.add(record.plan.seed);
}
for (let seed = 27000; seed <= 27011; seed++) existing.add(seed);
for (let seed = 28000; seed <= 28023; seed++) existing.add(seed);
const planned = new Set<number>();
for (const [opponent, split] of [["handcrafted", 0], ["zero", 1]] as const) {
	const old = JSON.parse(readFileSync(`docs/modern-pair-heldout-${opponent}.json`, "utf8"));
	const input = { ...old, seed: 5813, split, pairs: 200 };
	const parsed = parseModernStudyConfig(input);
	if (!parsed.ok) throw new Error(parsed.reason);
	for (let index = 0; index < input.pairs; index++) {
		const seed = modernStudyPlan(parsed.config, index, 0).seed;
		if (existing.has(seed) || planned.has(seed)) throw new Error(`duplicate deal seed ${seed}`);
		planned.add(seed);
	}
	writeFileSync(`docs/modern-pair-confirm-${opponent}.json`, `${JSON.stringify(input, null, "\t")}\n`);
}
if (planned.size !== 400 || existing.size === 0) throw new Error("seed check incomplete");
console.log(JSON.stringify({ existingSeeds: existing.size, distinctNewSeeds: planned.size }));
