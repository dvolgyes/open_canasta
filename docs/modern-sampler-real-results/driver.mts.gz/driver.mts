import { modernStartMatch } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-match.ts";
import { modernApplyAction } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-hand.ts";
import { mulberry32 } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/random.ts";
import { recordModernTransfer, type ModernPublicHistory } from "/home/dvolgyes/workspace/open_canasta-bot/src/game/modern-history.ts";
import { inferModern, observeModern } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-inference.ts";
import { chooseModernPosition } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-search.ts";
import { sampleCards as originalSample } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/card-knowledge.ts";
import { sampleCards as instrumentedSample } from "/tmp/open-canasta-card-knowledge-instrumented.mts";

for (let deal = 0; deal < 5; deal++) {
	const seed = 5137 + deal;
	const started = modernStartMatch(seed, deal % 4);
	if (!started.ok) throw new Error(started.reason);
	let hand = started.match.hand;
	let history: ModernPublicHistory | undefined;
	let decision = 0;
	while (decision < 300 && hand.outcome === null) {
		const observation = observeModern(hand, hand.turn, history);
		const belief = inferModern(observation.view, hand.turn, history);
		let fallbacks = 0;
		for (let trial = 0; trial < 5; trial++) {
			const randomSeed = 100000 + deal * 100000 + decision * 5 + trial;
			const expected = originalSample(belief, mulberry32(randomSeed));
			const actual = instrumentedSample(belief, mulberry32(randomSeed), () => { fallbacks++; });
			if (JSON.stringify(actual) !== JSON.stringify(expected)) throw new Error("instrumentation changed a sampled allocation");
		}
		const knownOther = belief.players.slice(0, 4).reduce((sum, row, seat) =>
			sum + (seat === hand.turn ? 0 : Object.values(row.minimum).reduce((a, b) => a + b, 0)), 0);
		console.log(JSON.stringify({ seed, decision, phase: hand.phase, knownOther, samples: 5, fallbacks }));
		const chosen = await chooseModernPosition(observation, {
			timeMs: 30000,
			maxIterations: 2,
			maxDepth: 3,
			rng: mulberry32(4000 + deal * 1000 + decision),
		});
		if (!chosen.action || chosen.iterations !== 2) throw new Error("search did not meet its budget");
		const applied = modernApplyAction(hand, hand.turn, chosen.action);
		if (!applied.ok) throw new Error(applied.reason);
		history = recordModernTransfer(history, hand, applied.hand);
		hand = applied.hand;
		decision++;
	}
	if (hand.outcome === null) throw new Error(`hand ${seed} exceeded action cap`);
}
