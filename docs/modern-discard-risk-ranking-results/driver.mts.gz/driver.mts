import { modernNewHand, modernApplyAction } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-hand.ts";
import { modernCardPoints } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-special-scoring.ts";
import { teamOf } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/hand.ts";
import { mulberry32 } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/random.ts";
import { recordModernTransfer, type ModernPublicHistory } from "/home/dvolgyes/workspace/open_canasta-bot/src/game/modern-history.ts";
import { observeModern } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-inference.ts";
import { chooseModernPosition } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-search.ts";
import { modernActionKey, modernPlayableActions } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-actions.ts";
import { MODERN_PRIOR_WEIGHTS, modernPriorFeatures, modernPriorValue } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-prior.ts";

for (let deal = 0; deal < 12; deal++) {
	const seed = 27000 + deal;
	const score = [0, 3000, 5000][Math.floor(deal / 4)];
	const started = modernNewHand({ seed, dealer: (deal % 4) as 0 | 1 | 2 | 3, teamScores: [score, score] });
	if (!started.ok) throw new Error(started.reason);
	let hand = started.hand;
	let history: ModernPublicHistory | undefined;
	let decision = 0;
	while (decision < 300 && hand.outcome === null) {
		const seat = hand.turn;
		const opposingCounts = hand.hands.flatMap((cards, other) =>
			teamOf(other as 0 | 1 | 2 | 3) !== teamOf(seat) ? [cards.length + hand.bonuses[other].length] : []);
		const minimumOpponentCount = Math.min(...opposingCounts);
		const urgency = Math.max(0, 4 - minimumOpponentCount) / 3;
		const actions = modernPlayableActions(hand, () => false);
		const scored = actions.map((action) => {
			let risk = 0;
			if (action.type === "discard") {
				const card = hand.hands[seat].find((item) => item.id === action.card);
				if (!card) throw new Error("discard card missing from acting hand");
				risk = urgency * modernCardPoints(card) / 20;
			}
			return { key: modernActionKey(hand, action), features: modernPriorFeatures(hand, action), risk };
		});
		const top = (weight: number) => {
			const scores = scored.map(({ key, features, risk }) => ({ key, value: modernPriorValue(features, MODERN_PRIOR_WEIGHTS, weight * risk) }));
			const best = Math.max(...scores.map((entry) => entry.value));
			return scores.filter((entry) => entry.value === best).map((entry) => entry.key).sort();
		};
		const baseline = top(0);
		const changed = Object.fromEntries([25, 50, 100].map((weight) => [weight, JSON.stringify(top(weight)) !== JSON.stringify(baseline)]));
		console.log(JSON.stringify({ seed, score, dealer: deal % 4, decision, phase: hand.phase, minimumOpponentCount, actions: actions.length, changed }));
		const chosen = await chooseModernPosition(observeModern(hand, seat, history), {
			timeMs: 30000, maxIterations: 2, maxDepth: 3,
			rng: mulberry32(94000 + deal * 1000 + decision),
		});
		if (!chosen.action || chosen.iterations !== 2) throw new Error("search did not meet its budget");
		const applied = modernApplyAction(hand, seat, chosen.action);
		if (!applied.ok) throw new Error(applied.reason);
		history = recordModernTransfer(history, hand, applied.hand);
		hand = applied.hand;
		decision++;
	}
	if (hand.outcome === null) throw new Error(`hand ${seed} exceeded action cap`);
}
