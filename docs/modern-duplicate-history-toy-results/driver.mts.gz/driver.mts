import { inferCards, sampleCards } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/card-knowledge.ts";
import { mulberry32 } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/random.ts";

const unknown = ["A2", "B", "C"];
let observedEvents = 0, remainingA = 0;
for (const initial of unknown) {
	const hand = ["A1", initial];
	for (let index = 0; index < hand.length; index++) {
		const discarded = hand[index];
		if (!discarded?.startsWith("A")) continue;
		observedEvents++;
		const retained = hand[1 - index];
		if (retained?.startsWith("A")) remainingA++;
	}
}
const belief = inferCards({
	deck: ["A", "A", "B", "C"],
	observer: 1,
	own: [],
	publicCards: ["A"],
	counts: [1, 0],
	history: {
		initialCounts: [1, 0],
		events: [
			{ player: 0, gained: ["A"], removed: [], drawn: 0 },
			{ player: 0, gained: [], removed: ["A"], drawn: 0 },
		],
	},
});
const rng = mulberry32(271828);
const samples = 20000;
let sampledA = 0;
for (let i = 0; i < samples; i++) {
	const first = sampleCards(belief, rng)[0];
	if (!first || first.length !== 1) throw new Error("invalid allocation");
	if (first[0] === "A") sampledA++;
}
console.log(JSON.stringify({ equallyLikelyObservedEvents: observedEvents, eventsWithARemaining: remainingA, modelPosterior: remainingA / observedEvents, samples, sampledA, sampledProbability: sampledA / samples, minimumA: belief.players[0]?.minimum.A ?? 0, maximumA: belief.players[0]?.maximum.A ?? 0 }));
