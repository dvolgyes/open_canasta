import { modernStartMatch } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-match.ts";
import { modernApplyAction } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-hand.ts";
import { mulberry32 } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/random.ts";
import { recordModernTransfer, type ModernPublicHistory } from "/home/dvolgyes/workspace/open_canasta-bot/src/game/modern-history.ts";
import { observeModern } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-inference.ts";
import { chooseModernPosition } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-search.ts";
import { modernPlayableActions } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-actions.ts";
import { MODERN_PRIOR_WEIGHTS, modernPriorFeatures } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-prior.ts";

const keys = Object.keys(MODERN_PRIOR_WEIGHTS);
for (let deal = 0; deal < 5; deal++) {
	const seed = 5137 + deal;
	const started = modernStartMatch(seed, deal % 4);
	if (!started.ok) throw new Error(started.reason);
	let hand = started.match.hand;
	let history: ModernPublicHistory | undefined;
	let decision = 0;
	while (decision < 300 && hand.outcome === null) {
		const actions = modernPlayableActions(hand, () => false);
		const features = actions.map((action) => modernPriorFeatures(hand, action));
		const varying = keys.filter((key) => new Set(features.map((value) => value[key])).size > 1);
		console.log(JSON.stringify({ seed, decision, phase: hand.phase, actions: actions.length, varying }));
		const observation = observeModern(hand, hand.turn, history);
		const chosen = await chooseModernPosition(observation, {
			timeMs: 30000,
			maxIterations: 2,
			maxDepth: 3,
			rng: mulberry32(4000 + deal * 1000 + decision),
		});
		if (!chosen.action || chosen.iterations !== 2) throw new Error("search did not meet its budget");
		const applied = modernApplyAction(hand, hand.turn, chosen.action);
		if (!applied.ok) throw new Error(applied.reason);
		history = recordModernTransfer(history, hand, applied.hand);
		hand = applied.hand;
		decision++;
	}
	if (hand.outcome === null) throw new Error(`hand ${seed} exceeded action cap`);
}
