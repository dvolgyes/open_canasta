import { readFileSync } from "node:fs";
import { performance } from "node:perf_hooks";
import { modernApplyAction } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-hand";
import { modernStartMatch } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-match";
import { mulberry32 } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/random";
import { recordModernTransfer, type ModernPublicHistory } from "/home/dvolgyes/workspace/open_canasta-bot/src/game/modern-history";
import { modernActionKey, modernSearchActions } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-actions";
import { observeModern } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-inference";
import { chooseModernPosition as baseline } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-search";
import { chooseModernPosition as candidate } from "./src/bot/modern-search";

const round = Number(process.argv[2] ?? 0);
const rows = readFileSync("docs/modern-band-sensitivity-results/results.jsonl", "utf8")
	.trim().split("\n").map((line) => JSON.parse(line));
const groups = new Map<string, typeof rows>();
for (const row of rows) {
	const key = `${row.score}:${row.seed}`;
	const group = groups.get(key) ?? [];
	if (row.decision !== group.length) throw new Error(`invalid trajectory ${key}`);
	group.push(row);
	groups.set(key, group);
}
if (groups.size !== 15 || rows.length !== 1260) throw new Error("unexpected source");
const samples = [];
for (const group of groups.values()) {
	const { seed, score } = group[0];
	const started = modernStartMatch(seed, (seed - 5137) % 4);
	if (!started.ok) throw new Error(started.reason);
	const teamScores = [score, score] as const;
	let hand = { ...started.match.hand, teamScores, turnStart: { ...started.match.hand.turnStart, teamScores } };
	let history: ModernPublicHistory | undefined;
	const positions = new Set([0.25, 0.75].map((fraction) => Math.floor((group.length - 1) * fraction)));
	for (const row of group) {
		if (hand.phase !== row.phase || hand.outcome !== null) throw new Error("phase mismatch");
		if (positions.has(row.decision)) {
			const observation = observeModern(hand, hand.turn, history);
			for (const [simulations, depth] of [[2, 3], [8, 8]] as const) {
				const timings = new Map<string, number>();
				const results = new Map<string, Awaited<ReturnType<typeof baseline>>>();
				const reversed = (Math.floor(samples.length / 2) + Number(simulations === 8) + round) % 2;
				for (const name of reversed ? ["candidate", "baseline"] : ["baseline", "candidate"]) {
					const start = performance.now();
					const result = await (name === "baseline" ? baseline : candidate)(observation, {
						timeMs: 30000,
						maxIterations: simulations,
						maxDepth: depth,
						rng: mulberry32(seed + row.decision + simulations),
					});
					timings.set(name, performance.now() - start);
					results.set(name, result);
				}
				const first = results.get("baseline"), second = results.get("candidate");
				if (!first || !second || first.iterations !== simulations || second.iterations !== simulations)
					throw new Error(`incomplete budget at ${seed}:${row.decision}`);
				if (JSON.stringify([first.action, first.iterations, first.choices]) !== JSON.stringify([second.action, second.iterations, second.choices]))
					throw new Error(`different search result at ${seed}:${row.decision}`);
				samples.push({ seed, score, decision: row.decision, simulations, depth, baselineMs: timings.get("baseline"), candidateMs: timings.get("candidate") });
			}
		}
		const action = modernSearchActions(hand).find((option) => modernActionKey(hand, option) === row.baselineAction);
		if (!action) throw new Error(`missing recorded action at ${seed}:${row.decision}`);
		const applied = modernApplyAction(hand, hand.turn, action);
		if (!applied.ok) throw new Error(applied.reason);
		history = recordModernTransfer(history, hand, applied.hand);
		hand = applied.hand;
	}
	if (!hand.outcome) throw new Error("unfinished trajectory");
}
if (samples.length !== 60) throw new Error("incomplete sample");
process.stdout.write(`${JSON.stringify({ samples })}\n`);
