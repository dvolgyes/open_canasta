import { performance } from "node:perf_hooks";
import { modernApplyAction } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-hand";
import { modernStartMatch } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-match";
import { mulberry32 } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/random";
import { recordModernTransfer, type ModernPublicHistory } from "/home/dvolgyes/workspace/open_canasta-bot/src/game/modern-history";
import { observeModern } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-inference";
import { chooseModernPosition as baseline } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-search";
import { chooseModernPosition as candidate } from "./src/bot/modern-search";

const samples = [];
const round = Number(process.argv[2] ?? 0);
for (const [group, seed] of [202409, 202410, 202411].entries()) {
	const started = modernStartMatch(seed, (seed % 4) as 0 | 1 | 2 | 3);
	if (!started.ok) throw new Error(started.reason);
	let hand = started.match.hand;
	let history: ModernPublicHistory | undefined;
	for (let decision = 0; decision < 6; decision++) {
		if (hand.outcome) throw new Error("hand ended before the planned sample");
		const observation = observeModern(hand, hand.turn, history);
		let move;
		for (const [simulations, depth] of [[2, 3], [8, 8]] as const) {
			const results = new Map<string, Awaited<ReturnType<typeof baseline>>>();
			const duration = new Map<string, number>();
			const reversed = (group * 6 + decision + Number(simulations === 8) + round) % 2;
			for (const name of reversed ? ["candidate", "baseline"] : ["baseline", "candidate"]) {
				const time = performance.now();
				const result = await (name === "baseline" ? baseline : candidate)(observation, {
					timeMs: 30000,
					maxIterations: simulations,
					maxDepth: depth,
					rng: mulberry32(seed + decision + simulations),
				});
				duration.set(name, performance.now() - time);
				results.set(name, result);
			}
			const first = results.get("baseline"), second = results.get("candidate");
			if (!first || !second || first.iterations !== simulations || second.iterations !== simulations)
				throw new Error(`incomplete budget at ${seed}:${decision}`);
			if (JSON.stringify([first.action, first.iterations, first.choices]) !== JSON.stringify([second.action, second.iterations, second.choices]))
				throw new Error(`different search result at ${seed}:${decision}`);
			if (simulations === 2) move = first.action;
			samples.push({ group, seed, decision, simulations, depth, baselineMs: duration.get("baseline"), candidateMs: duration.get("candidate") });
		}
		if (!move) throw new Error("missing action");
		const applied = modernApplyAction(hand, hand.turn, move);
		if (!applied.ok) throw new Error(applied.reason);
		history = recordModernTransfer(history, hand, applied.hand);
		hand = applied.hand;
	}
}
process.stdout.write(`${JSON.stringify({ samples })}\n`);
