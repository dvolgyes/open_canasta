import { inferCards as baseline } from "./baseline";
import { inferCards as candidate } from "./candidate";

const faces = ["A", "B", "C", "D"];
let accepted = 0;
let rejected = 0;
const evaluate = (fn: typeof baseline, input: Parameters<typeof baseline>[0]) => {
	try {
		return { ok: true, value: JSON.stringify(fn(input)) };
	} catch (error) {
		if (!(error instanceof Error)) throw error;
		return { ok: false, value: error.message };
	}
};
for (let mask = 0; mask < 4096; mask++) {
	const excludedByPlayer = [[], ...[0, 1, 2].map((row) =>
		faces.filter((_, i) => (mask & (1 << (row * 4 + i))) !== 0),
	)];
	const input = {
		deck: ["A", "A", "B", "C", "D"],
		observer: 0,
		own: ["A"],
		publicCards: [],
		counts: [1, 1, 1, 1],
		excludedByPlayer,
	};
	const first = evaluate(baseline, input);
	const second = evaluate(candidate, input);
	if (JSON.stringify(first) !== JSON.stringify(second))
		throw new Error(`different result at mask ${mask}: ${JSON.stringify({ first, second })}`);
	if (first.ok) accepted++;
	else rejected++;
}
process.stdout.write(`${JSON.stringify({ total: accepted + rejected, accepted, rejected })}\n`);
