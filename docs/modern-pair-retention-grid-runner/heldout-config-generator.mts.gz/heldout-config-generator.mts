import { readFileSync, readdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { modernStudyPlan, parseModernStudyConfig } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/research/modern-study.ts";

const existing = new Set<number>();
for (const path of readFileSync("/tmp/open-canasta-all-pair-files.txt", "utf8").trim().split("\n").filter(Boolean)) {
	const record = JSON.parse(readFileSync(path, "utf8"));
	if (typeof record.plan?.seed === "number") existing.add(record.plan.seed);
}
const files = ["docs/modern-pair-confirm-handcrafted.json", "docs/modern-pair-confirm-zero.json", "docs/modern-pair-pile-heldout-config.json", ...["docs/modern-pair-pile-grid-configs", "docs/modern-pair-retention-grid-configs"].flatMap((dir) => readdirSync(dir).map((name) => join(dir, name)))];
for (const path of files) {
	const parsed = parseModernStudyConfig(JSON.parse(readFileSync(path, "utf8")));
	if (!parsed.ok) throw new Error(parsed.reason);
	for (let i = 0; i < parsed.config.pairs; i++) existing.add(modernStudyPlan(parsed.config, i, 0).seed);
}
for (let seed = 27000; seed <= 27011; seed++) existing.add(seed);
for (let seed = 28000; seed <= 28023; seed++) existing.add(seed);
const planned = new Set<number>();
for (const [opponent, split] of [["handcrafted", 0], ["zero", 1]] as const) {
	const old = JSON.parse(readFileSync(`docs/modern-pair-heldout-${opponent}.json`, "utf8"));
	delete old.aPairThreatV1Weight;
	const input = { ...old, seed: 8913, split, a: { ...old.a, discardPair: 25 } };
	const parsed = parseModernStudyConfig(input);
	if (!parsed.ok) throw new Error(parsed.reason);
	for (let i = 0; i < parsed.config.pairs; i++) {
		const seed = modernStudyPlan(parsed.config, i, 0).seed;
		if (existing.has(seed) || planned.has(seed)) throw new Error(`duplicate deal seed ${seed}`);
		planned.add(seed);
	}
	writeFileSync(`docs/modern-pair-retention-heldout-${opponent}.json`, `${JSON.stringify(input, null, "\t")}\n`);
}
if (planned.size !== 100 || existing.size < 900) throw new Error("seed check incomplete");
console.log(JSON.stringify({ existingSeeds: existing.size, distinctNewSeeds: planned.size }));
