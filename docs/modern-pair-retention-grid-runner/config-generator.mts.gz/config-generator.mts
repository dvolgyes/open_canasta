import { readFileSync, readdirSync, writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";
import { modernStudyPlan, parseModernStudyConfig } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/research/modern-study.ts";

const existing = new Set<number>();
for (const path of readFileSync("/tmp/open-canasta-all-pair-files.txt", "utf8").trim().split("\n").filter(Boolean)) {
	const record = JSON.parse(readFileSync(path, "utf8"));
	if (typeof record.plan?.seed === "number") existing.add(record.plan.seed);
}
const files = ["docs/modern-pair-confirm-handcrafted.json", "docs/modern-pair-confirm-zero.json", "docs/modern-pair-pile-heldout-config.json", ...readdirSync("docs/modern-pair-pile-grid-configs").map((name) => join("docs/modern-pair-pile-grid-configs", name))];
for (const path of files) {
	const parsed = parseModernStudyConfig(JSON.parse(readFileSync(path, "utf8")));
	if (!parsed.ok) throw new Error(parsed.reason);
	for (let i = 0; i < parsed.config.pairs; i++) existing.add(modernStudyPlan(parsed.config, i, 0).seed);
}
for (let seed = 27000; seed <= 27011; seed++) existing.add(seed);
for (let seed = 28000; seed <= 28023; seed++) existing.add(seed);
const template = JSON.parse(readFileSync("docs/modern-pair-threat-grid-configs/pos50-0.json", "utf8"));
delete template.aPairThreatV1Weight;
const planned = new Set<number>();
const directory = "docs/modern-pair-retention-grid-configs";
mkdirSync(directory, { recursive: true });
for (const [score, split] of [[0, 0], [3000, 1], [5000, 2]] as const) {
	for (const weight of [-100, -25, 0, 25, 50, 100]) {
		const input = { ...template, seed: 7913, split, initialTeamScore: score, a: { ...template.a, discardPair: weight } };
		const parsed = parseModernStudyConfig(input);
		if (!parsed.ok) throw new Error(parsed.reason);
		if (weight === -100) for (let pair = 0; pair < 8; pair++) {
			const seed = modernStudyPlan(parsed.config, pair, 0).seed;
			if (existing.has(seed) || planned.has(seed)) throw new Error(`duplicate deal seed ${seed}`);
			planned.add(seed);
		}
		const label = `${weight < 0 ? `neg${-weight}` : `pos${weight}`}-${score}`;
		writeFileSync(`${directory}/${label}.json`, `${JSON.stringify(input, null, "\t")}\n`);
	}
}
if (planned.size !== 24 || existing.size < 800) throw new Error("seed check incomplete");
console.log(JSON.stringify({ existingSeeds: existing.size, distinctNewSeeds: planned.size, configurations: 18 }));
