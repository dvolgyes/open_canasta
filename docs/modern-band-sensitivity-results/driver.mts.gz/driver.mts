import { modernStartMatch } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-match.ts";
import { modernApplyAction } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/modern-hand.ts";
import { mulberry32 } from "/home/dvolgyes/workspace/open_canasta-bot/src/canasta/random.ts";
import { recordModernTransfer, type ModernPublicHistory } from "/home/dvolgyes/workspace/open_canasta-bot/src/game/modern-history.ts";
import { observeModern } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-inference.ts";
import { chooseModernPosition } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-search.ts";
import { modernActionKey } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-actions.ts";
import { MODERN_PRIOR_WEIGHTS } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-prior.ts";
import { readFileSync } from "node:fs";

const candidate = JSON.parse(readFileSync("docs/modern-opening-band-training-results/update-10.json", "utf8")).candidate;
for (const score of [0, 3000, 5000]) for (let deal = 0; deal < 5; deal++) {
	const seed = 5137 + deal;
	const started = modernStartMatch(seed, deal % 4);
	if (!started.ok) throw new Error(started.reason);
	const teamScores = [score, score] as const;
	let hand = { ...started.match.hand, teamScores, turnStart: { ...started.match.hand.turnStart, teamScores } };
	let history: ModernPublicHistory | undefined;
	let decision = 0;
	while (decision < 300 && hand.outcome === null) {
		const view = observeModern(hand, hand.turn, history);
		const options = { timeMs: 30000, maxIterations: 2, maxDepth: 3 };
		const baseline = await chooseModernPosition(view, {
			...options,
			priorWeights: MODERN_PRIOR_WEIGHTS,
			rng: mulberry32(4000 + deal * 1000 + decision),
		});
		const trained = await chooseModernPosition(view, {
			...options,
			priorWeights: candidate,
			rng: mulberry32(4000 + deal * 1000 + decision),
		});
		if (!baseline.action || !trained.action) throw new Error("missing action");
		console.log(JSON.stringify({
			score,
			seed,
			decision,
			phase: hand.phase,
			baselineIterations: baseline.iterations,
			trainedIterations: trained.iterations,
			baselineRootChoices: baseline.choices.length,
			trainedRootChoices: trained.choices.length,
			baselineAction: modernActionKey(hand, baseline.action),
			trainedAction: modernActionKey(hand, trained.action),
		}));
		const applied = modernApplyAction(hand, hand.turn, baseline.action);
		if (!applied.ok) throw new Error(applied.reason);
		history = recordModernTransfer(history, hand, applied.hand);
		hand = applied.hand;
		decision++;
	}
	if (hand.outcome === null) throw new Error(`hand ${seed} exceeded action cap`);
}
