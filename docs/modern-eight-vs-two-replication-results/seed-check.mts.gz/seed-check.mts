import { readFileSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { modernStudyPlan, parseModernStudyConfig } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/research/modern-study.ts";

const existing = new Set<number>();
for (const path of readFileSync("/tmp/open-canasta-all-pair-files.txt", "utf8").trim().split("\n").filter(Boolean)) {
	const record = JSON.parse(readFileSync(path, "utf8"));
	if (typeof record.plan?.seed === "number") existing.add(record.plan.seed);
}
const files = ["docs/modern-pair-confirm-handcrafted.json", "docs/modern-pair-confirm-zero.json", "docs/modern-pair-pile-heldout-config.json", "docs/modern-pair-retention-heldout-handcrafted.json", "docs/modern-pair-retention-heldout-zero.json", ...["docs/modern-pair-pile-grid-configs", "docs/modern-pair-retention-grid-configs", "docs/modern-retention-eight-hand-configs"].flatMap((dir) => readdirSync(dir).map((name) => join(dir, name)))];
for (const path of files) {
	const parsed = parseModernStudyConfig(JSON.parse(readFileSync(path, "utf8")));
	if (!parsed.ok) throw new Error(parsed.reason);
	for (let i = 0; i < parsed.config.pairs; i++) existing.add(modernStudyPlan(parsed.config, i, 0).seed);
}
for (let seed = 27000; seed <= 27011; seed++) existing.add(seed);
for (let seed = 28000; seed <= 28023; seed++) existing.add(seed);
const original = JSON.parse(readFileSync("docs/modern-band-vs-handcrafted-screen.json", "utf8"));
const parsed = parseModernStudyConfig({ ...original, seed: 10913, split: 0, pairs: 12, maxHands: 1 });
if (!parsed.ok) throw new Error(parsed.reason);
const planned = new Set<number>();
for (let pair = 0; pair < 12; pair++) {
	const seed = modernStudyPlan(parsed.config, pair, 0).seed;
	if (existing.has(seed) || planned.has(seed)) throw new Error(`duplicate deal seed ${seed}`);
	planned.add(seed);
}
if (planned.size !== 12 || existing.size < 1000) throw new Error("seed check incomplete");
console.log(JSON.stringify({ existingSeeds: existing.size, distinctNewSeeds: planned.size }));
