import { readFileSync } from "node:fs";

const records = readFileSync(process.argv[2], "utf8").trim().split("\n").map(JSON.parse);
if (records.length !== 24) throw new Error("expected 24 hands");
let wins = 0, losses = 0, ties = 0, decisions8 = 0, decisions2 = 0;
const seen = new Set();
for (const record of records) {
	const key = `${record.pair}:${record.side}`;
	if (seen.has(key) || record.pair < 0 || record.pair >= 12 || ![0, 1].includes(record.side)) throw new Error("invalid scheduled leg");
	seen.add(key);
	const { result, counts } = record;
	if (!["hand cap", "scenario hand"].includes(result.reason) || counts.a.misses || counts.b.misses || counts.a.simulations !== 8 * counts.a.decisions || counts.b.simulations !== 2 * counts.b.decisions || counts.a.decisions + counts.b.decisions !== result.actions) throw new Error("invalid hand or budget");
	const own = result.scores[result.plan.aTeam], other = result.scores[1 - result.plan.aTeam];
	if (own > other) wins++;
	else if (own < other) losses++;
	else ties++;
	decisions8 += counts.a.decisions;
	decisions2 += counts.b.decisions;
}
console.log(JSON.stringify({ hands: records.length, wins, losses, ties, decisions8, decisions2, predictedThresholdMet: wins >= 14 }));
