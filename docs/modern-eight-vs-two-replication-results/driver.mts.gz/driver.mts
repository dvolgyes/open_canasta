import { readFileSync } from "node:fs";
import { MODERN_PRIOR_WEIGHTS } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/modern-prior.ts";
import { modernResearchAgent, playModernMatch, type ModernResearchAgent } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/research/modern-arena.ts";
import { modernStudyPlan, parseModernStudyConfig } from "/home/dvolgyes/workspace/open_canasta-bot/src/bot/research/modern-study.ts";

const original = JSON.parse(readFileSync("docs/modern-band-vs-handcrafted-screen.json", "utf8"));
const parsed = parseModernStudyConfig({ ...original, seed: 10913, split: 0, pairs: 12, maxHands: 1 });
if (!parsed.ok) throw new Error(parsed.reason);
const policies = {
	a: modernResearchAgent({ priorWeights: MODERN_PRIOR_WEIGHTS, simulations: 8, timeMs: 30000, depth: 3 }),
	b: modernResearchAgent({ priorWeights: MODERN_PRIOR_WEIGHTS, simulations: 2, timeMs: 30000, depth: 3 }),
};
for (let pair = 0; pair < 12; pair++) for (const side of [0, 1] as const) {
	const config = { ...parsed.config, initialTeamScore: [0, 3000, 5000][Math.floor(pair / 4)] };
	const plan = modernStudyPlan(config, pair, side);
	const counts = { a: { decisions: 0, simulations: 0, misses: 0 }, b: { decisions: 0, simulations: 0, misses: 0 } };
	const result = await playModernMatch(plan, (_seat, name): ModernResearchAgent => ({
		async decide(observation, context) {
			const decision = await policies[name].decide(observation, context);
			if (decision.ok) {
				counts[name].decisions++;
				counts[name].simulations += decision.simulations;
				counts[name].misses += Number(decision.deadlineStopped || decision.simulations !== (name === "a" ? 8 : 2));
			}
			return decision;
		},
	}));
	if (result.reason !== "hand cap" && result.reason !== "scenario hand") throw new Error(`unexpected hand result: ${result.reason}`);
	if (counts.a.misses || counts.b.misses || counts.a.decisions + counts.b.decisions !== result.actions) throw new Error("missed decision budget");
	const { elapsedMs: _elapsedMs, ...stableResult } = result;
	console.log(JSON.stringify({ pair, side, result: stableResult, counts }));
}
