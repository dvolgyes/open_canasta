import { pathToFileURL } from "node:url";

const load = (path: string) => import(pathToFileURL(`${process.cwd()}/${path}`).href);
const { playModernMatch, modernResearchAgent } = await load("src/bot/research/modern-arena.ts");
const { MODERN_PRIOR_WEIGHTS } = await load("src/bot/modern-prior.ts");
const { inferModern, sampleModernPosition } = await load("src/bot/modern-inference.ts");
const { modernApplyAction } = await load("src/canasta/modern-hand.ts");
const { modernViewFor } = await load("src/canasta/modern-view.ts");
const { mulberry32 } = await load("src/canasta/random.ts");
for (const seed of Array.from({ length: 20 }, (_, index) => index + 100)) {
	let decisions = 0, positions = 0, undos = 0, retracts = 0;
	const factory = () => {
		const agent = modernResearchAgent({ priorWeights: MODERN_PRIOR_WEIGHTS, simulations: 2, depth: 3, timeMs: 30000 });
		return { decide(observation, context) {
			decisions++;
			if (observation.canUndo) {
				positions++;
				const belief = inferModern(observation.view, observation.seat, observation.history);
				let sample = sampleModernPosition(observation, belief, mulberry32(seed + decisions * 100));
				if (observation.canRetract) {
					if (!modernApplyAction(sample, observation.seat, { type: "retract" }).ok)
						throw new Error(`missing retraction: seed ${seed}, decision ${decisions}`);
					retracts++;
				}
				for (const expected of [...observation.undoViews].reverse()) {
					const step = modernApplyAction(sample, observation.seat, { type: "undo" });
					if (!step.ok) throw new Error(`missing undo: seed ${seed}, decision ${decisions}`);
					sample = step.hand;
					if (JSON.stringify(modernViewFor(sample, observation.seat)) !== JSON.stringify(expected))
						throw new Error(`undo view mismatch: seed ${seed}, decision ${decisions}`);
					undos++;
				}
			}
			return agent.decide(observation, context);
		} };
	};
	const result = await playModernMatch({ seed, policySeed: 51017, dealer: 0, aTeam: 0, maxHands: 1, maxActionsPerHand: 300 }, factory);
	if ((result.reason !== "hand cap" && result.status !== "complete") || result.deadlineStops !== 0 || result.simulations !== 2 * result.actions)
		throw new Error(`invalid hand: ${seed}`);
	process.stdout.write(`${JSON.stringify({seed,decisions,positions,undos,retracts})}\n`);
}
