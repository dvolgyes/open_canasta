import { createHash } from "node:crypto";
import { pathToFileURL } from "node:url";

const load = (path: string) => import(pathToFileURL(`${process.cwd()}/${path}`).href);
const { playModernMatch, modernResearchAgent } = await load("src/bot/research/modern-arena.ts");
const { MODERN_PRIOR_WEIGHTS } = await load("src/bot/modern-prior.ts");
const seed = Number(process.argv[2]);
const trace: unknown[] = [];
const factory = () => {
	const agent = modernResearchAgent({ priorWeights: MODERN_PRIOR_WEIGHTS, simulations: 8, depth: 8, timeMs: 30000 });
	return { async decide(observation, context) {
		const result = await agent.decide(observation, context);
		if (result.ok) {
			const action = result.action;
			const face = (id) => {
				const card = observation.view.hand.find((item) => item.id === id);
				if (!card) throw new Error("action card is not in the observed hand");
				return `${card.rank}${card.suit ?? ""}`;
			};
			const key = action.type === "discard" ? [action.type, face(action.card)] :
				action.type === "meld" || action.type === "extend" || action.type === "take-pile" ?
				[action.type, action.type === "extend" ? action.meldId : "", action.cards.map(face).toSorted()] :
				action.type === "special" ? [action.type, action.kind] : [action.type];
			trace.push([observation.seat, observation.view.phase, key]);
		}
		return result;
	} };
};
const result = await playModernMatch({ seed, policySeed: 51017, dealer: 0, aTeam: 0, maxHands: 1, maxActionsPerHand: 300 }, factory);
if (result.reason !== "hand cap" || result.deadlineStops !== 0 || result.simulations !== 8 * result.actions) throw new Error("invalid fixed hand");
process.stdout.write(`${JSON.stringify({seed,scores:result.scores,actions:result.actions,simulations:result.simulations,traceSha256:createHash("sha256").update(JSON.stringify(trace)).digest("hex")})}\n`);
