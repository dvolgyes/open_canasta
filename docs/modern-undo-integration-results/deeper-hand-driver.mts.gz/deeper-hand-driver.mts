import { pathToFileURL } from "node:url";

const load = (path: string) => import(pathToFileURL(`${process.cwd()}/${path}`).href);
const { playModernMatch, modernResearchAgent } = await load("src/bot/research/modern-arena.ts");
const { MODERN_PRIOR_WEIGHTS } = await load("src/bot/modern-prior.ts");
const { inferModern, sampleModernPosition } = await load("src/bot/modern-inference.ts");
const { mulberry32 } = await load("src/canasta/random.ts");
const config = { priorWeights: MODERN_PRIOR_WEIGHTS, simulations: 8, depth: 8, timeMs: 30000 };
let undoDecisions = 0;
let maxUndoSnapshots = 0;
let longHistoryCost = null;
const result = await playModernMatch({ seed: Number(process.argv[2] ?? 9137), policySeed: 51017, dealer: 0, aTeam: 0, maxHands: 1, maxActionsPerHand: 300 }, () => {
	const agent = modernResearchAgent(config);
	return { decide(observation, context) {
		if (observation.canUndo) undoDecisions++;
		maxUndoSnapshots = Math.max(maxUndoSnapshots, observation.undoViews?.length ?? 0);
		if (longHistoryCost === null && (observation.undoViews?.length ?? 0) >= 7) {
			const belief = inferModern(observation.view, observation.seat, observation.history);
			const started = performance.now();
			for (let i = 0; i < 10; i++) sampleModernPosition(observation, belief, mulberry32(i));
			longHistoryCost = { snapshots: observation.undoViews.length, samples: 10, elapsedMs: performance.now() - started };
		}
		return agent.decide(observation, context);
	} };
});
process.stdout.write(`${JSON.stringify({ ...result, undoDecisions, maxUndoSnapshots, longHistoryCost })}\n`);
